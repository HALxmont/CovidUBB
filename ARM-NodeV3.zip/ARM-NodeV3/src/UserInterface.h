/*
 *      UserInterface.h
 *      Created on: 18-03-2017
 *      Author: Krzysztof Herman
 *	    kherman@ubiobio.cl
 */

#ifndef USERINTERFACE_H_
#define USERINTERFACE_H_
#include <stdio.h>


/*--------------------------------------- Functions -------------------------*/
/**
  * @brief  Shows program info at the beginning
  * @param  none
  * @note 
  * @retval None
  */
void info(void);
/**
  * @brief  Shows main menu 
  * @param  none
  * @note 
  * @retval None
  */
void MainMenu(void);
/**
  * @brief  Main Choice selector which switch between menus according to the level
  * @param  pointer to a uint8_t data from UART that represents an option
  * @note   Use it in UART RX interrupt 
  * @retval None
  */
void ChoiceSelector(char *choice);



void ClearScreen(void);

void SetDebugMode(void);
void ResetDebugMode(void);


#endif
