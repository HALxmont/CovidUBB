/*
 * delays.c
 *
 *  Created on: 10-01-2019
 *      Author: K Herman
 */


#include "delays.h"
#include "stm32f10x.h"
#include "SPISD_DRV.h"

static __IO uint32_t sysTickCounter;

/**
  * @brief  This function decrements global variable sysTickCounter and is called
  *         in SysTickHandler
  * @param  None
  * @retval None
  */
void TimeTick_Decrement(void) {
	if (sysTickCounter != 0x00) {
		sysTickCounter--;
	}
}

/**
  * @brief  This function implements delay of n miliseconds
  * @param  n miliseconds
  * @retval None
  */
void delay_nms(uint32_t n) {
	sysTickCounter = n;
	while (sysTickCounter != 0) {
	}
}


/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler()
{
	sdcard_systick_timerproc();
	TimeTick_Decrement();

}

