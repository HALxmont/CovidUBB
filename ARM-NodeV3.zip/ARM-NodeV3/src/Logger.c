/******************************************************************************
 * Logger.c
 *  Created on: 10-01-2019
 *      Author: K Herman
 *****************************************************************************/

#include "stm32f10x.h"
#include "Logger.h"
#include "ff.h"
#include "stdio.h"
#include "ArmNode.h"
#include "sht11_drv_sensibus.h"

volatile Measurement meas;
extern ErrorTypeDef App_Error;
extern uint8_t DEBUG;
extern uint8_t SD_Write;

/**
 * @brief  This function handles MLX90614 reads.
 * @param  I2C address of the MLX90616 sensor
 * @retval Value in a format T [Celcius] * 100,
 */

/*
 * timeouts cada while
 * error reporting cada while
 *
 * */
int16_t ReadMLX(uint8_t address) {

	uint8_t byte1, byte2, pec;
	int16_t result;
	uint16_t temp;
	uint32_t timeout = 0xFFFF;

	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_GetFlagStatusTimeout;
			return 0x8000;
		}
	}
	// Generate start condition
	I2C_GenerateSTART(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT_Timeout;
			return 0x8000;
		}
	}
	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Transmitter);
	while (!(I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)
			== SUCCESS || I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT))) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout;
			return 0x8000;
		}

	}

	if (I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT)) {
		I2C_ClearFlag(I2C2, I2C_FLAG_TIMEOUT);
		I2C_ClearFlag(I2C2, I2C_FLAG_AF);
		I2C_ClearFlag(I2C2, I2C_FLAG_BERR);
		I2C_Cmd(I2C2, DISABLE);
		I2C_Cmd(I2C2, ENABLE);
		App_Error.I2C = I2C_FLAG_TIMEOUTErr;
		return 0x8000;
	}

	timeout = 0xFFFF;
	I2C_SendData(I2C2, 0x07);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
			return 0x8000;
		}
	}

	timeout = 0xFFFF;
	I2C_GenerateSTART(I2C2, ENABLE);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT2_Timeout;
			return 0x8000;
		}
	}

	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Receiver);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED_Timeout;
			return 0x8000;
		}
	}

	timeout = 0xFFFF;
	I2C_AcknowledgeConfig(I2C2, ENABLE);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED_Timeout;
			return 0x8000;
		}
	}
	// Read and return data byte from I2C data register
	byte1 = I2C_ReceiveData(I2C2);
	I2C_AcknowledgeConfig(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED2_Timeout;
			return 0x8000;
		}
	}
	// Read and return data byte from I2C data register
	byte2 = I2C_ReceiveData(I2C2);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED3_Timeout;
			return 0x8000;
		}
	}
	// Read and return data byte from I2C data register
	//pec =  I2C_ReceiveData(I2C2);
	/*
	 *
	 * implement CRC-8 here
	 *
	 * */

	// Generate I2C stop condition
	I2C_GenerateSTOP(I2C2, ENABLE);
	// Wait until I2C stop condition is finished
	timeout = 0xFFFF;
	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_STOPF)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_FLAG_STOPF_Timeout;
			return 0x8000;
		}
	}


	temp = (uint16_t) byte2 << 8;
	temp = (uint16_t) (temp + byte1);

	if (temp & 0x8000)
	  return 0x8000;
	else{
		result = (int16_t) temp << 1;
		result = (int16_t) result - 27315;
	return result;
	}

}

int16_t ReadMLXAmbient(uint8_t address) {

	uint8_t byte1, byte2, pec;
	int16_t result;
	uint16_t temp;
	uint32_t timeout = 0xFFFF;

	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_GetFlagStatusTimeout;
			return 0x8000;
		}
	}
	// Generate start condition
	I2C_GenerateSTART(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT_Timeout;
			return 0x8000;
		}
	}
	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Transmitter);
	while (!(I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)
			== SUCCESS || I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT))) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout;
			return 0x8000;
		}

	}

	if (I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT)) {
		I2C_ClearFlag(I2C2, I2C_FLAG_TIMEOUT);
		I2C_ClearFlag(I2C2, I2C_FLAG_AF);
		I2C_ClearFlag(I2C2, I2C_FLAG_BERR);
		I2C_Cmd(I2C2, DISABLE);
		I2C_Cmd(I2C2, ENABLE);
		App_Error.I2C = I2C_FLAG_TIMEOUTErr;
		return 0x8000;
	}

	timeout = 0xFFFF;
	I2C_SendData(I2C2, 0x06);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
			return 0x8000;
		}
	}

	timeout = 0xFFFF;
	I2C_GenerateSTART(I2C2, ENABLE);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT2_Timeout;
			return 0x8000;
		}
	}

	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Receiver);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED_Timeout;
			return 0x8000;
		}
	}

	timeout = 0xFFFF;
	I2C_AcknowledgeConfig(I2C2, ENABLE);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED_Timeout;
			return 0x8000;
		}
	}
	// Read and return data byte from I2C data register
	byte1 = I2C_ReceiveData(I2C2);
	I2C_AcknowledgeConfig(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED2_Timeout;
			return 0x8000;
		}
	}
	// Read and return data byte from I2C data register
	byte2 = I2C_ReceiveData(I2C2);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED3_Timeout;
			return 0x8000;
		}
	}
	// Read and return data byte from I2C data register
	//pec =  I2C_ReceiveData(I2C2);
	/*
	 *
	 * implement CRC-8 here
	 *
	 * */

	// Generate I2C stop condition
	I2C_GenerateSTOP(I2C2, ENABLE);
	// Wait until I2C stop condition is finished
	timeout = 0xFFFF;
	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_STOPF)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_FLAG_STOPF_Timeout;
			return 0x8000;
		}
	}


	temp = (uint16_t) byte2 << 8;
	temp = (uint16_t) (temp + byte1);

	if (temp & 0x8000)
	  return 0x8000;
	else{
		result = (int16_t) temp << 1;
		result = (int16_t) result - 27315;
	return result;
	}

}

void  WriteMLX_EP(uint8_t address, uint8_t reg, uint16_t value, uint8_t pec) {

	uint8_t regep = reg | 0x20;
	uint32_t timeout = 0xFFFF;

	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_GetFlagStatusTimeout;
		}
	}
	// Generate start condition
	I2C_GenerateSTART(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT_Timeout;
		}
	}
	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Transmitter);
	/* Wait for Acknowledgement */
	while (!(I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == SUCCESS || I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT))) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout;
		}

	}

	if (I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT)) {
			I2C_ClearFlag(I2C2, I2C_FLAG_TIMEOUT);
			I2C_ClearFlag(I2C2, I2C_FLAG_AF);
			I2C_ClearFlag(I2C2, I2C_FLAG_BERR);
			I2C_Cmd(I2C2, DISABLE);
			I2C_Cmd(I2C2, ENABLE);
			App_Error.I2C = I2C_FLAG_TIMEOUTErr;
		}

		timeout = 0xFFFF;
		I2C_SendData(I2C2, regep);
		while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
			timeout--;
			if (timeout == 0) {
				App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
			}
		}


		timeout = 0xFFFF;
		I2C_SendData(I2C2, (uint8_t) 0x0000FFFF & value);
		while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
			timeout--;
			if (timeout == 0) {
				App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
			}
		}



		timeout = 0xFFFF;
		I2C_SendData(I2C2, (uint8_t) (0x0000FFFF & (value >> 8) ));
		while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
			timeout--;
			if (timeout == 0) {
				App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
			}
		}


//		timeout = 0xFFF;
//		I2C_SendData(I2C2, pec);
//		while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
//			timeout--;
//			if (timeout == 0) {
//				App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
//			}
//		}


		I2C_GenerateSTOP(I2C2, ENABLE);
		// Wait until I2C stop condition is finished
		timeout = 0xFFFF;
		while (I2C_GetFlagStatus(I2C2, I2C_FLAG_STOPF)) {
			timeout--;
			if (timeout == 0) {
				App_Error.I2C = I2C_FLAG_STOPF_Timeout;
			}
		}


}

uint16_t ReadMLX_EP(uint8_t address, uint8_t reg) {

	uint8_t regep = reg | 0x20;
	uint8_t byte1, byte2, pec;
	int16_t result;
	uint32_t timeout = 0xFFFF;

	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_BUSY)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_GetFlagStatusTimeout;
			return 0x1000;
		}
	}
	// Generate start condition
	I2C_GenerateSTART(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT_Timeout;
			return 0x1000;
		}
	}
	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Transmitter);
	while (!(I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)
			== SUCCESS || I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT))) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout;
			return 0x1000;
		}

	}

	if (I2C_GetFlagStatus(I2C2, I2C_FLAG_TIMEOUT)) {
		I2C_ClearFlag(I2C2, I2C_FLAG_TIMEOUT);
		I2C_ClearFlag(I2C2, I2C_FLAG_AF);
		I2C_ClearFlag(I2C2, I2C_FLAG_BERR);
		I2C_Cmd(I2C2, DISABLE);
		I2C_Cmd(I2C2, ENABLE);
		App_Error.I2C = I2C_FLAG_TIMEOUTErr;
		return 0x1000;
	}

	timeout = 0xFFFF;
	I2C_SendData(I2C2, regep);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout;
			return 0x1000;
		}
	}

	timeout = 0xFFFF;
	I2C_GenerateSTART(I2C2, ENABLE);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_MODE_SELECT2_Timeout;
			return 0x1000;
		}
	}

	timeout = 0xFFFF;
	I2C_Send7bitAddress(I2C2, address << 1, I2C_Direction_Receiver);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED_Timeout;
			return 0x1000;
		}
	}

	timeout = 0xFFFF;
	I2C_AcknowledgeConfig(I2C2, ENABLE);
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED_Timeout;
			return 0x1000;
		}
	}
	// Read and return data byte from I2C data register
	byte1 = I2C_ReceiveData(I2C2);
	I2C_AcknowledgeConfig(I2C2, ENABLE);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED2_Timeout;
			return 0x1000;
		}
	}
	// Read and return data byte from I2C data register
	byte2 = I2C_ReceiveData(I2C2);
	timeout = 0xFFFF;
	while (!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_EVENT_MASTER_BYTE_RECEIVED3_Timeout;
			return 0x1000;
		}
	}
	// Read and return data byte from I2C data register
	pec = I2C_ReceiveData(I2C2);
	/*
	 *
	 * implement CRC-8 here
	 *
	 * */

	// Generate I2C stop condition
	I2C_GenerateSTOP(I2C2, ENABLE);
	// Wait until I2C stop condition is finished
	timeout = 0xFFFF;
	while (I2C_GetFlagStatus(I2C2, I2C_FLAG_STOPF)) {
		timeout--;
		if (timeout == 0) {
			App_Error.I2C = I2C_FLAG_STOPF_Timeout;
			return 0x1000;
		}
	}

	result = (uint16_t) byte2 << 8;
	result = (uint16_t) (result + byte1);

	return result;

}


void ResetBKPCounter(void) {

	PWR_BackupAccessCmd(ENABLE);
	BKP_WriteBackupRegister(BKP_DR6, 0x0000);
	PWR_BackupAccessCmd(DISABLE);

}

uint16_t GetBKPCounter(void) {

	uint16_t data;
	PWR_BackupAccessCmd(ENABLE);
	data = BKP_ReadBackupRegister(BKP_DR6);
	PWR_BackupAccessCmd(DISABLE);
	return data;

}
void IncBKPCounter(void) {

	uint16_t cnt;

	PWR_BackupAccessCmd(ENABLE);
	cnt = BKP_ReadBackupRegister(BKP_DR6);
	cnt++;
	BKP_WriteBackupRegister(BKP_DR6, cnt);
	PWR_BackupAccessCmd(DISABLE);

}

void ResetBKPLogCounter(void) {

	PWR_BackupAccessCmd(ENABLE);
	BKP_WriteBackupRegister(BKP_DR7, 0x0000);
	PWR_BackupAccessCmd(DISABLE);

}

uint16_t GetBKPLogCounter(void) {

	uint16_t data;
	PWR_BackupAccessCmd(ENABLE);
	data = BKP_ReadBackupRegister(BKP_DR7);
	PWR_BackupAccessCmd(DISABLE);
	return data;

}
void IncBKPLogCounter(void) {

	uint16_t cnt;

	PWR_BackupAccessCmd(ENABLE);
	cnt = BKP_ReadBackupRegister(BKP_DR7);
	cnt++;
	BKP_WriteBackupRegister(BKP_DR7, cnt);
	PWR_BackupAccessCmd(DISABLE);

}

uint8_t SavetoFile(char *filename) {

	char HD_Log[512];
	FIL file;
	FRESULT fr;
	UINT len, bytes_written;
	uint32_t tm;
	char timebuff[128];
	char measbuff[128];
	RTC_Init_Time rtc;
	uint8_t tec, rec;

	tec = CAN_GetLSBTransmitErrorCounter(CAN1);
	rec = CAN_GetReceiveErrorCounter(CAN1);

	tm = RTC_GetCounter();
	RTC_GetDateTime(tm, &rtc);


	sprintf(timebuff, "%d-%d-%d %d:%d:%d", rtc.year, rtc.month, rtc.day,rtc.hour, rtc.minute, rtc.second);
	sprintf(measbuff,"%d; %d; %d; %d; %d; %d; %d; %d; %d; %d; %d; %d; %d; %d",
			    	meas.MeasCnt, meas.CoreTemp, meas.Vcc, meas.MLX[0], meas.MLX[1],
					meas.MLX[2], meas.MLX[3], meas.MLX[4], meas.MLX[5],
					meas.ReadSHTHum, meas.ReadSHTTemp, App_Error.I2C, tec , rec);
	len = sprintf(HD_Log, "%s; %d; %s\n", timebuff, NODE_ID, measbuff);

	if (DEBUG)
		USART_puts(USART1, HD_Log);

	 if(SD_Write){
	//__disable_irq();
	/* Opens an existing file. If not exist, creates a new file. */
	fr = f_open(&file, filename, FA_OPEN_APPEND | FA_WRITE | FA_READ);
	if (fr == FR_OK) {
		fr = f_write(&file, HD_Log, len, &bytes_written);
		if (bytes_written != len || fr != FR_OK) {
				App_Error.FAT = FAT_WriteError;
			if (DEBUG)
				USART_puts(USART1, "Writing error \n");
		}

	} else {
		App_Error.FAT = FAT_Error;
		if (DEBUG) {
			USART_puts(USART1, "File open error \n");
			measbuff[0] = '\0';
			sprintf(measbuff, " Fat status %d \n", fr);
			USART_puts(USART1, measbuff);
		}
	}
	fr = f_close(&file);
	//__enable_irq();
	 }

	return fr;
}

void MakeMeasurement(void) {

	uint16_t num;

	DisableIRQ();
	num = GetBKPCounter();
	meas.MeasCnt = num;
	meas.CoreTemp = (uint16_t) GetCoreTemp();
	meas.Vcc = (uint16_t) GetSystemVoltage();
	meas.MLX[0] = ReadMLX(MLX1);
	meas.MLX[1] = ReadMLX(MLX2);
	meas.MLX[2] = ReadMLX(MLX3);
	meas.MLX[3] = ReadMLX(MLX4);
	meas.MLX[4] = ReadMLX(MLX5);
	meas.MLX[5] = ReadMLX(MLX6);
	meas.ReadSHTHum = ReadSHT1xHum();
	meas.ReadSHTTemp = ReadSHT1xTemp();
	IncBKPCounter();
	EnableIRQ();
}

uint32_t GetCoreTemp(void) {

	uint16_t adc_value;
	int16_t temperature;
	const uint16_t V25 = 1750;	// when V25=1.41V at ref 3.3V
	const uint16_t Avg_Slope = 5; //when avg_slope=4.3mV/C at ref 3.3V

	InitADCTemp();
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
	while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)) {
	}
	adc_value = ADC_GetConversionValue(ADC1);
	temperature = (uint16_t) ((V25 - adc_value) / Avg_Slope + 25);
	ADC_Cmd(ADC1, DISABLE);
	ADC_DeInit(ADC1);
	return temperature;
}

uint32_t GetSystemVoltage(void) {

	uint32_t adc_value, voltage;

	InitADC();
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);

	while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)) {

	};
	adc_value = ADC_GetConversionValue(ADC1);
	voltage = adc_value * 3300 * 6;
	voltage = voltage >> 12;
	ADC_Cmd(ADC1, DISABLE);
	ADC_DeInit(ADC1);
	return voltage;
}

int16_t ReadSHT1xTemp(void) {

	int16_t raw_temp;

	SHT11_StartTemperature();
	delay_nms(_SHT11.delay);
	raw_temp = SHT11_ReadTemperature();

	if (raw_temp > 0) {

		delay_nms(1);

	}

	return raw_temp-3940;
}

uint16_t ReadSHT1xHum(void) {

	uint16_t hum;

	SHT11_StartHumidity();
	delay_nms(_SHT11.delay);
	hum = (uint16_t) SHT11_ReadHumidity();

	return hum;

}

void DisableIRQ(void) {

	//NVIC_DisableIRQ(TIM2_IRQn);
	//NVIC_DisableIRQ(TIM3_IRQn);
	//NVIC_DisableIRQ(TIM1_CC_IRQn);
	NVIC_DisableIRQ(TIM4_IRQn);
	NVIC_DisableIRQ(CAN1_SCE_IRQn);
	NVIC_DisableIRQ(RTCAlarm_IRQn);
	NVIC_DisableIRQ(RTC_IRQn);
	NVIC_DisableIRQ(USART1_IRQn);
	NVIC_DisableIRQ(USART2_IRQn);
	//NVIC_DisableIRQ(EXTI15_10_IRQn);
	NVIC_DisableIRQ(EXTI9_5_IRQn);
	NVIC_DisableIRQ(USB_HP_CAN1_TX_IRQn);
	NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);

}

void EnableIRQ(void) {

	//NVIC_EnableIRQ(TIM2_IRQn);
	//NVIC_EnableIRQ(TIM3_IRQn);
	//NVIC_EnableIRQ(TIM1_CC_IRQn);
	NVIC_EnableIRQ(TIM4_IRQn);
	NVIC_EnableIRQ(CAN1_SCE_IRQn);
	NVIC_EnableIRQ(RTCAlarm_IRQn);
	NVIC_EnableIRQ(RTC_IRQn);
	NVIC_EnableIRQ(USART1_IRQn);
	NVIC_EnableIRQ(USART2_IRQn);
	//NVIC_EnableIRQ(EXTI15_10_IRQn);
	NVIC_EnableIRQ(EXTI9_5_IRQn);
	NVIC_EnableIRQ(USB_HP_CAN1_TX_IRQn);
	NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);

}

/****************************************************************************/

