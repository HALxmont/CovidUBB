/**
 * @file doxygen_c.h
 * @author My Self
 * @date 9 Sep 2012
 * @brief File containing example of doxygen usage for quick reference.
 *
 * Here typically goes a more extensive explanation of what the header
 * defines. Doxygens tags are words preceeded by either a backslash @\
 * or by an at symbol @@.
 * @see http://www.stack.nl/~dimitri/doxygen/docblocks.html
 * @see http://www.stack.nl/~dimitri/doxygen/commands.html
 */

#include "HardwareInit.h"
#include "stm32f10x.h"
#include "sht11_drv_sensibus.h"



/**
 * @brief HardwareInit invoking initialization function
 * @param  none
 * @return none
 * @note Something to note.
 */
void HardwareInit(void){

	PeriphClockInit();
	Init_GPIO();
	USART1_Init();
	Init_SystTick();
	init_SPI1();
	Init_I2C();
    SHT11_Init();
	USART1_Init();
	Init_SystTick();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    init_CAN();
    Init_EXTI15_10();
    //Init_EXTI();
	Init_TMR4(17578);
    InitPWM();

    //Init_IWDG();
   // Init_WWDG();

}

/**
 * @brief Periph Clock configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void PeriphClockInit(void){

	/* Enable GPIO */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOB , ENABLE);
    /* Enable clock for USART1, AFIO */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO, ENABLE);
    /* Enable SPI1 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    /* Enable TIM3 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,  ENABLE);
	/* Enable TIM2 */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,  ENABLE);
    /* Enable TIM4 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,  ENABLE);

	/* Enable I2C1 */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,  ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2,  ENABLE);
	/* Enable WWDG */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG,  ENABLE);
	/* Enable CAN1 */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1,  ENABLE);
	/* Enable PWR and BKP */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP | RCC_APB1ENR_PWREN,  ENABLE);

	/* Enable clock for USART2 tested*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,  ENABLE);

	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG,  ENABLE);


	/* Enable clock for SPI2 tested*/
	// RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2,  ENABLE);

	 //RCC_ITConfig(RCC_IT_CSS, ENABLE);
	 //RCC_ClearITPendingBit(RCC_IT_CSS);

	 NVIC_EnableIRQ(RCC_IRQn);
}


/**
 * @brief GPIO configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_GPIO(void)
{
    GPIO_InitTypeDef gpio_init_struct;

    /* GPIOA PIN9 alternative function Tx tested */
    gpio_init_struct.GPIO_Pin = GPIO_Pin_9;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpio_init_struct);
    /* GPIOA PIN10 alternative function Rx tested*/
    gpio_init_struct.GPIO_Pin = GPIO_Pin_10;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &gpio_init_struct);


    /*GPIOA PIN2  USART2 TX  tested */
    gpio_init_struct.GPIO_Pin = GPIO_Pin_2;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init_struct);

    /*GPIOA PIN2  USART2  RX  tested */
    gpio_init_struct.GPIO_Pin = GPIO_Pin_3;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init_struct);

    /*GPIOB PIN9  CAN TX*/
    gpio_init_struct.GPIO_Pin = GPIO_Pin_9;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio_init_struct);
    /*GPIOB PIN8  CAN RX*/
    gpio_init_struct.GPIO_Pin = GPIO_Pin_8;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_IPU;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio_init_struct);
    GPIO_PinRemapConfig(GPIO_Remap1_CAN1, ENABLE);


    gpio_init_struct.GPIO_Pin = GPIO_Pin_4;       //NSS
    gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init_struct);

    gpio_init_struct.GPIO_Pin = GPIO_Pin_5;      //SCK
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpio_init_struct);

    gpio_init_struct.GPIO_Pin = GPIO_Pin_6;      //MISO
    gpio_init_struct.GPIO_Mode= GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpio_init_struct);

    gpio_init_struct.GPIO_Pin = GPIO_Pin_7;      //MOSI
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpio_init_struct);


    gpio_init_struct.GPIO_Pin = GPIO_Pin_10;      //SCL
    gpio_init_struct.GPIO_Mode= GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &gpio_init_struct);

    gpio_init_struct.GPIO_Pin = GPIO_Pin_11;      //SDA
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &gpio_init_struct);


    /*GPIOA PA0 Analog IN*/
    gpio_init_struct.GPIO_Pin = GPIO_Pin_0;
    gpio_init_struct.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &gpio_init_struct);

    /* PA1 alternative function TIM2 CH2 tested */
	gpio_init_struct.GPIO_Pin = GPIO_Pin_1;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &gpio_init_struct);
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);

    /* PB1 PIN9 alternative function TIM3 CH4 tested */
    gpio_init_struct.GPIO_Pin = GPIO_Pin_1;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &gpio_init_struct);
    GPIO_ResetBits(GPIOB,GPIO_Pin_1);

    /* PB0 PIN9 alternative function TIM3 CH3 tested */
	gpio_init_struct.GPIO_Pin = GPIO_Pin_0;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &gpio_init_struct);
	GPIO_ResetBits(GPIOB,GPIO_Pin_0);

    /* PB4 PIN40 alternative function TIM3 CH1  tested*/
	gpio_init_struct.GPIO_Pin = GPIO_Pin_4;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &gpio_init_struct);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_NoJTRST, ENABLE);
	GPIO_ResetBits(GPIOB,GPIO_Pin_4);


	/* PA8 alternative function TIM1 CH1 tested */
	gpio_init_struct.GPIO_Pin = GPIO_Pin_8;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &gpio_init_struct);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8);

	/* PA11 alternative function TIM1 CH4 tested */
	gpio_init_struct.GPIO_Pin = GPIO_Pin_11;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &gpio_init_struct);
	GPIO_ResetBits(GPIOA,GPIO_Pin_11);

	gpio_init_struct.GPIO_Pin = GPIO_Pin_15;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &gpio_init_struct);

	// led toogle
	gpio_init_struct.GPIO_Pin = GPIO_Pin_14;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &gpio_init_struct);


	/* PB5 External Interrupt */
	gpio_init_struct.GPIO_Pin = GPIO_Pin_5;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &gpio_init_struct);

	/* PA12 External Interrupt enable */
	gpio_init_struct.GPIO_Pin = GPIO_Pin_12;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &gpio_init_struct);



	/*-------------------- SPI2 configuration tested -----------------*/
    gpio_init_struct.GPIO_Pin = GPIO_Pin_12;       //NSS
    gpio_init_struct.GPIO_Mode = GPIO_Mode_Out_PP;
    gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio_init_struct);

//    gpio_init_struct.GPIO_Pin = GPIO_Pin_13;      //SCK
//    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
//    GPIO_Init(GPIOB, &gpio_init_struct);
//
//    gpio_init_struct.GPIO_Pin = GPIO_Pin_14;      //MISO
//    gpio_init_struct.GPIO_Mode= GPIO_Mode_IN_FLOATING;
//    GPIO_Init(GPIOB, &gpio_init_struct);
//
//    gpio_init_struct.GPIO_Pin = GPIO_Pin_15;      //MOSI
//    gpio_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
//    GPIO_Init(GPIOB, &gpio_init_struct);
    /*-------------------- SPI2 configuration       -----------------*/
}


/**
 * @brief SystTick initialization function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_SystTick(void){

	// Update SystemCoreClock value
	SystemCoreClockUpdate();
	// Configure the SysTick timer to overflow every 1ms
	SysTick_Config(SystemCoreClock / 1000);
	NVIC_SetPriority(SysTick_IRQn, 0x04);
}


/**
 * @brief External Interrupt PB5 configuration to Wake Up function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_EXTI(void){

	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;

	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource5);

	EXTI_InitStruct.EXTI_Line = EXTI_Line5;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_Init(&EXTI_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x00;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

	NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/**
 * @brief External Interrupt configuration to Zero-Cross sensor function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_EXTI15_10(void){

	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;

	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource12);

	EXTI_InitStruct.EXTI_Line = EXTI_Line12;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

	NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/**
 * @brief Timers for PWM configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void InitPWM(void){

	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef        TIM_OCInitStructure;
	NVIC_InitTypeDef         NVIC_InitStruct;

	u16 DC_Val = 59999;

	TIM_CCPreloadControl(TIM2, DISABLE);
	TIM_CCPreloadControl(TIM3, DISABLE);
	TIM_CCPreloadControl(TIM1, DISABLE);

	/* -----------------------------------------------------------------------
	    TIM2 Configuration: generate  PWM signal:
	    TIM2 CLK = 72 MHz, Prescaler = 0xC, TIM2 counter clock = 6 MHz
	    TIM2 ARR Register = 57141 => TIM2 Frequency = TIM2 counter clock/(ARR + 1)
	    TIM2 Frequency = 105 Hz. ---Period Msm = 9.5 ms
	    TIM2 Channel4 duty cycle = (TIM2_CCR1/ TIM2_ARR)* 100 = 50%
	  ----------------------------------------------------------------------- */
	  /* Time base configuration */
	TIM_TimeBaseStructure.TIM_Period = 59999;
	TIM_TimeBaseStructure.TIM_Prescaler = 12;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

	/* PWM1 Mode configuration: Channel4 */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Disable;
	TIM_OCInitStructure.TIM_Pulse = DC_Val;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;

	TIM_OC2Init(TIM2, &TIM_OCInitStructure);   // PA1
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);   // PB0
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);   // PB1
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);   // PB4
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);   // PA8
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);   // PA11


	NVIC_InitStruct.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_Init(&NVIC_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel = TIM1_CC_IRQn;
	NVIC_Init(&NVIC_InitStruct);

	NVIC_EnableIRQ(TIM2_IRQn);
	NVIC_EnableIRQ(TIM3_IRQn);
	NVIC_EnableIRQ(TIM1_CC_IRQn);


    TIM_ITConfig(TIM2, TIM_IT_CC2, ENABLE);
    TIM_ITConfig(TIM3, TIM_IT_CC3, ENABLE);
    TIM_ITConfig(TIM3, TIM_IT_CC4, ENABLE);
    TIM_ITConfig(TIM3, TIM_IT_CC1, ENABLE);
    TIM_ITConfig(TIM1, TIM_IT_CC1, ENABLE);
    TIM_ITConfig(TIM1, TIM_IT_CC4, ENABLE);

    NVIC_SetPriority(TIM2_IRQn, 0x8 );
    NVIC_SetPriority(TIM3_IRQn, 0x8 );
    NVIC_SetPriority(TIM1_CC_IRQn, 0x8 );

	/* TIM2 enable counter */
	TIM_Cmd(TIM2, ENABLE);
	TIM_Cmd(TIM3, ENABLE);
	TIM_Cmd(TIM1, ENABLE);

}

/**
 * @brief I2C configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_I2C(void){

	I2C_InitTypeDef I2C_InitStruct;
	I2C_InitStruct.I2C_Mode = I2C_Mode_SMBusDevice;
	I2C_InitStruct.I2C_ClockSpeed = 50000;
	I2C_InitStruct.I2C_OwnAddress1 = 0x00;
	I2C_InitStruct.I2C_Ack = I2C_Ack_Enable;
	I2C_InitStruct.I2C_DutyCycle  = I2C_DutyCycle_2;
	I2C_Init(I2C2, &I2C_InitStruct);
	I2C_Cmd(I2C2, ENABLE);
}

/**
 * @brief USART1 configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void USART1_Init(void)
{
    /* USART configuration structure for USART1 */
    USART_InitTypeDef usart1_init_struct;

    /* Enable USART1 */
    USART_Cmd(USART1, DISABLE);
    /* Baud rate 9600, 8-bit data, One stop bit
     * No parity, Do both Rx and Tx, No HW flow control
     */
    usart1_init_struct.USART_BaudRate = 115200;
    usart1_init_struct.USART_WordLength = USART_WordLength_8b;
    usart1_init_struct.USART_StopBits = USART_StopBits_1;
    usart1_init_struct.USART_Parity = USART_Parity_No ;
    usart1_init_struct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    usart1_init_struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    /* Configure USART1 */
    USART_Init(USART1, &usart1_init_struct);
    /* Enable RXNE interrupt */
    USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    /* Enable USART1 global interrupt */
    NVIC_SetPriority(USART1_IRQn, 0x8 );

    NVIC_EnableIRQ(USART1_IRQn);
    USART_Cmd(USART1, ENABLE);
}

/**
 * @brief USART2 configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void USART2_Init(void)
{
    /* USART configuration structure for USART2 */
    USART_InitTypeDef usart1_init_struct;

    /* Enable USART1 */
    USART_Cmd(USART2, ENABLE);
    /* Baud rate 9600, 8-bit data, One stop bit
     * No parity, Do both Rx and Tx, No HW flow control
     */
    usart1_init_struct.USART_BaudRate = 9200;
    usart1_init_struct.USART_WordLength = USART_WordLength_8b;
    usart1_init_struct.USART_StopBits = USART_StopBits_1;
    usart1_init_struct.USART_Parity = USART_Parity_No ;
    usart1_init_struct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    usart1_init_struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    /* Configure USART1 */
    USART_Init(USART2, &usart1_init_struct);
    /* Enable RXNE interrupt */
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    /* Enable USART1 global interrupt */
    NVIC_SetPriority(USART2_IRQn, 0x8 );

    NVIC_EnableIRQ(USART2_IRQn);
}

/**
 * @brief Testing function for switch GPIO A2
 * @param  none
 * @return none
 * @note Something to note.
 */
void led_toggle(void)
{
    /* Read LED output (GPIOA PIN8) status */
    uint8_t led_bit = GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_14);

    /* If LED output set, clear it */
    if(led_bit == (uint8_t)Bit_SET)
    {
        GPIO_ResetBits(GPIOB, GPIO_Pin_14);
    }
    /* If LED output clear, set it */
    else
    {
        GPIO_SetBits(GPIOB, GPIO_Pin_14);
    }
}

/**
 * @brief USART print
 * @param1 set USART
 * @param2 characters to print
 * @return none
 * @note Something to note.
 */
void USART_puts(USART_TypeDef* USARTx, volatile char *s){

	while(*s){
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET ){

		}
			USART_SendData(USARTx, *s);
		*s++;
	}
}



void Init_TMR4(uint16_t period){

	TIM_TimeBaseInitTypeDef TimerInitStructure;
	NVIC_InitTypeDef NVIC_InitStruct;

	TimerInitStructure.TIM_Prescaler = 4096;
	TimerInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TimerInitStructure.TIM_Period = period;
	TimerInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TimerInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM4, &TimerInitStructure);
	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);


    /* Enable TIMER4 global interrupt */

	NVIC_InitStruct.NVIC_IRQChannel = TIM4_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM4, ENABLE);

}

/**
 * @brief CAN configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void init_CAN(void){

	CAN_InitTypeDef CAN_InitStructure;
	CAN_FilterInitTypeDef CAN_FilterInitStructure;
	NVIC_InitTypeDef  NVIC_InitStructure;
    uint32_t fidh, fidl, fmhi, fmlo;
    uint32_t filter_id, filter_mask;

	/* CAN cell init */
	CAN_DeInit(CAN1);
	CAN_InitStructure.CAN_TTCM = DISABLE;
	CAN_InitStructure.CAN_ABOM = DISABLE;
	CAN_InitStructure.CAN_AWUM = DISABLE;
	CAN_InitStructure.CAN_NART = ENABLE;
	CAN_InitStructure.CAN_RFLM = DISABLE;
	CAN_InitStructure.CAN_TXFP = ENABLE;
	CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;
	CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;
	/* CAN Baudrate  */
	CAN_InitStructure.CAN_BS1 = CAN_BS1_13tq;
	CAN_InitStructure.CAN_BS2 = CAN_BS2_2tq;
	CAN_InitStructure.CAN_Prescaler = 45;
	CAN_Init(CAN1, &CAN_InitStructure);


    /* ID to be accepted */
    filter_id = 0x4;
	filter_mask = 0x4;

    fidh   =  ((filter_id << 5)  | (filter_id >> (32 - 5))) & 0xFFFF; // STID[10:0] & EXTID[17:13]
    fidl =  (filter_id >> (11 - 3)) & 0xFFF8; // EXID[12:5] & 3 Reserved bits
    fmhi   =  ((filter_mask << 5)  | (filter_mask >> (32 - 5))) & 0xFFFF;
    fmlo  =   (filter_mask >> (11 - 3)) & 0xFFF8;


	/* CAN filter init */
	CAN_FilterInitStructure.CAN_FilterNumber = 1;
	CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdList;
	CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
	CAN_FilterInitStructure.CAN_FilterIdHigh = fidh;
	CAN_FilterInitStructure.CAN_FilterIdLow = fidl;
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh = fmhi;
	CAN_FilterInitStructure.CAN_FilterMaskIdLow = fmlo;
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment = 0;
	CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;

	CAN_FilterInit(&CAN_FilterInitStructure);

    /* ID to be accepted */
    filter_id = 0x7;
	filter_mask = 0x7;

    fidh   =  ((filter_id << 5)  | (filter_id >> (32 - 5))) & 0xFFFF;
    fidl =  (filter_id >> (11 - 3)) & 0xFFF8;
    fmhi   =  ((filter_mask << 5)  | (filter_mask >> (32 - 5))) & 0xFFFF;
    fmlo  =   (filter_mask >> (11 - 3)) & 0xFFF8;

	/* CAN filter init */
	CAN_FilterInitStructure.CAN_FilterNumber = 2;
	CAN_FilterInitStructure.CAN_FilterIdHigh = fidh;
	CAN_FilterInitStructure.CAN_FilterIdLow = fidl;
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh = fmhi;
	CAN_FilterInitStructure.CAN_FilterMaskIdLow = fmlo;
	CAN_FilterInit(&CAN_FilterInitStructure);


	NVIC_InitStructure.NVIC_IRQChannel=USB_HP_CAN1_TX_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	CAN_ITConfig(CAN1, CAN_IT_TME, DISABLE);

	NVIC_InitStructure.NVIC_IRQChannel=USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);


	NVIC_InitStructure.NVIC_IRQChannel=CAN1_SCE_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
	NVIC_Init(&NVIC_InitStructure);
	CAN_ITConfig(CAN1, CAN_IT_EWG | CAN_IT_EPV | CAN_IT_LEC | CAN_IT_ERR | CAN_IT_BOF, ENABLE);

	NVIC_EnableIRQ(USB_HP_CAN1_TX_IRQn);
    NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);
    NVIC_EnableIRQ(CAN1_SCE_IRQn);

}

/**
 * @brief SPI1 configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void init_SPI1(void){

	  SPI_InitTypeDef  SPI_InitStructure;

	  SPI_I2S_DeInit(SPI1);
	  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128;  //128: 375kHZ, 8: 6MHz, 4: 12MHz, 2: 24MHz
	  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	  SPI_InitStructure.SPI_CRCPolynomial = 7;
	  SPI_Init(SPI1, &SPI_InitStructure);
	  SPI_DataSizeConfig(SPI1, SPI_DataSize_8b);
	  GPIO_SetBits(GPIOA, GPIO_Pin_4);
	  SPI_Cmd(SPI1, ENABLE);
}

/**
 * @brief SPI2 configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void init_SPI2(void){

	  SPI_InitTypeDef  SPI_InitStructure;

	  SPI_I2S_DeInit(SPI2);
	  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_128;  //128: 375kHZ, 8: 6MHz, 4: 12MHz, 2: 24MHz
	  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	  SPI_InitStructure.SPI_CRCPolynomial = 7;
	  SPI_Init(SPI2, &SPI_InitStructure);
	  SPI_DataSizeConfig(SPI2, SPI_DataSize_8b);
	  GPIO_SetBits(GPIOB, GPIO_Pin_12);
	  SPI_Cmd(SPI2, ENABLE);
}

/**
 * @brief IWDG configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_IWDG(void){

	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
    IWDG_SetPrescaler(IWDG_Prescaler_64);
    IWDG_SetReload(0x0FFF);
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Disable);
}

/**
 * @brief WWDG configuration function
 * @param  none
 * @return none
 * @note Something to note.
 */
void Init_WWDG(void){

	WWDG_DeInit();
	WWDG_SetPrescaler(WWDG_Prescaler_8);
	WWDG_EnableIT();
	NVIC_EnableIRQ(WWDG_IRQn);
	WWDG_ClearFlag();
	WWDG_SetCounter(0x71);
	WWDG_SetWindowValue(0x2F);
}

/**
 * @brief RTC configuration function
 * @param  structure of data time
 * @return none
 * @note Something to note.
 */
void Init_RTC(RTC_Init_Time *rtc){

	uint32_t counter;
	NVIC_InitTypeDef NVIC_InitStruct;

	PWR_BackupAccessCmd(ENABLE);
	//BKP_DeInit();

	RCC_LSEConfig(RCC_LSE_ON);
	/* Wait till LSI is ready */
	while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);

	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
	RCC_RTCCLKCmd(ENABLE);
	RTC_ClearFlag(RTC_FLAG_RSF);
	RTC_WaitForSynchro();
	RTC_WaitForLastTask();
    RTC_ITConfig(RTC_IT_SEC, DISABLE);
    RTC_WaitForLastTask();
    RTC_ITConfig(RTC_IT_ALR, ENABLE);
    RTC_WaitForLastTask();

    RTC_EnterConfigMode();
    RTC_SetPrescaler(32767);
    RTC_WaitForLastTask();
    counter = RTC_GetRTC_Counter(rtc);
    RTC_SetCounter(counter);
    RTC_WaitForLastTask();
    RTC_ExitConfigMode();

	NVIC_InitStruct.NVIC_IRQChannel = RTC_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x05;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x01;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

    RTC_WaitForLastTask();
    RTC_SetAlarm(RTC_GetCounter() + 5);
    RTC_WaitForLastTask();

    PWR_BackupAccessCmd(DISABLE);

}

/**
 * @brief Get data time of RTC
 * @param1 Counter RTC
 * @param2 Initial Time
 * @return none
 * @note Something to note.
 */
void RTC_GetDateTime(uint32_t RTC_Counter, RTC_Init_Time *rtc){
	unsigned long time;
	unsigned long t1, a, b, c, d, e, m;
	int year = 0;
	int mon = 0;
	int mday = 0;
	int hour = 0;
	int min = 0;
	int sec = 0;
	uint64_t jd = 0;;
	uint64_t jdn = 0;

	jd = ((RTC_Counter+43200)/(86400>>1)) + (2440587<<1) + 1;
	jdn = jd>>1;

	time = RTC_Counter;
	t1 = time/60;
	sec = time - t1*60;

	time = t1;
	t1 = time/60;
	min = time - t1*60;

	time = t1;
	t1 = time/24;
	hour = time - t1*24;

	a = jdn + 32044;
	b = (4*a+3)/146097;
	c = a - (146097*b)/4;
	d = (4*c+3)/1461;
	e = c - (1461*d)/4;
	m = (5*e+2)/153;
	mday = e - (153*m+2)/5 + 1;
	mon = m + 3 - 12*(m/10);
	year = 100*b + d - 4800 + (m/10);

	rtc->day = mday;
	rtc->hour = hour;
	rtc->minute = min;
	rtc->month = mon;
	rtc->year = year;
	rtc->second = sec;

}

/**
 * @brief Get RTC counter of RTC
 * @param1 Counter RTC
 * @return none
 * @note Something to note.
 */
uint32_t RTC_GetRTC_Counter(RTC_Init_Time *rtc) {
	uint8_t a;
	uint16_t y;
	uint8_t m;
	uint32_t JDN;

	a=(14-rtc->month)/12;
	y=rtc->year+4800-a;
	m=rtc->month+(12*a)-3;

	JDN=rtc->day;
	JDN+=(153*m+2)/5;
	JDN+=365*y;
	JDN+=y/4;
	JDN+=-y/100;
	JDN+=y/400;
	JDN = JDN -32045;
	JDN = JDN - JULIAN_DATE_BASE;
	JDN*=86400;
	JDN+=(rtc->hour*3600);
	JDN+=(rtc->minute*60);
	JDN+=(rtc->second);

	return JDN;
}

/**
 * @brief ADC Internal Tempeture configure function
 * @param none
 * @return none
 * @note Something to note.
 */
void InitADCTemp(void){


	RCC_ADCCLKConfig (RCC_PCLK2_Div6);
	// enable ADC system clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	//ADC
	ADC_InitTypeDef ADC_InitStructure;
	// define ADC config
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;	// we work in continuous sampling mode
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 1;

	ADC_RegularChannelConfig(ADC1, ADC_Channel_TempSensor, 1, ADC_SampleTime_239Cycles5); // define regular conversion config
	ADC_Init (ADC1, &ADC_InitStructure);	//set config of ADC1

	// Enable Temperature sensor
	ADC_TempSensorVrefintCmd(ENABLE);

	// Enable ADC
	ADC_Cmd (ADC1, ENABLE);	//enable ADC1

	//	ADC calibration (optional, but recommended at power on)
	ADC_ResetCalibration(ADC1);	// Reset previous calibration
	while(ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);	// Start new calibration (ADC must be off at that time)
	while(ADC_GetCalibrationStatus(ADC1));

	ADC_Cmd (ADC1,ENABLE);	//enable ADC1


}

/**
 * @brief ADC configure function
 * @param none
 * @return none
 * @note Something to note.
 */
void InitADC(void){


	RCC_ADCCLKConfig (RCC_PCLK2_Div6);
	// enable ADC system clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	//ADC
	ADC_InitTypeDef ADC_InitStructure;
	// define ADC config
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;	// we work in continuous sampling mode
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 1;

	ADC_RegularChannelConfig(ADC1,ADC_Channel_0, 1,ADC_SampleTime_28Cycles5); // define regular conversion config
	ADC_Init (ADC1, &ADC_InitStructure);	//set config of ADC1

	// Enable ADC
	ADC_Cmd (ADC1, ENABLE);	//enable ADC1

	//	ADC calibration (optional, but recommended at power on)
	ADC_ResetCalibration(ADC1);	// Reset previous calibration
	while(ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);	// Start new calibration (ADC must be off at that time)
	while(ADC_GetCalibrationStatus(ADC1));

	ADC_Cmd (ADC1,ENABLE);	//enable ADC1


}

void HW_delay(void){

	for(int i=0;i<100000;i++);

}
