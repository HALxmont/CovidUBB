/*
 *  ArmNode.h
 *
 *  Created on: 26-02-2019
 *  Author: Krzysztof Herman
 */

#ifndef ARMNODE_H_
#define ARMNODE_H_


#include "ff.h"
#include "stm32f10x.h"

#define NODE_ID   0x12


#define MAX_PWM 56000
#define MIN_PWM 0



#define IntegralLimit 10000

#ifndef PowerMode
	//#define PowerMode
#endif

typedef struct {

	uint8_t			DeltaT;
	uint16_t  		kp;
	uint16_t		ki;
	uint16_t		kd;
	int             error;
    int             integral;
    int             derivativo;
	int 			pastError;

} ControlInitTypeDef;


typedef enum {WAITING = 0, DONE = !WAITING} AppStatus;

typedef enum {
	Error_App_NoErr = 0,
	I2C_GetFlagStatusTimeout,
	I2C_EVENT_MASTER_MODE_SELECT_Timeout,
	I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout,
	I2C_FLAG_TIMEOUTErr,
	I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout,
	I2C_EVENT_MASTER_MODE_SELECT2_Timeout,
	I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED_Timeout,
	I2C_EVENT_MASTER_BYTE_RECEIVED_Timeout,
	I2C_EVENT_MASTER_BYTE_RECEIVED2_Timeout,
	I2C_EVENT_MASTER_BYTE_RECEIVED3_Timeout,
	I2C_FLAG_STOPF_Timeout,
	CAN_EWG,
	CAN_EPV,
	CAN_BOF,
	CAN_ERR,
	CAN_LEC,
	FAT_WriteError,
	FAT_Error,
} AppError;

typedef struct {

	AppError  I2C;
	AppError  FAT;
	AppError  CAN;
	uint8_t   tec;
	uint8_t   rec;
	uint8_t   lec;

} ErrorTypeDef;


void SanityCheck();
void readallmlx(void);
void ShowID(void);
void ShowCurrentTime(void);
FRESULT scan_files (char* path);
void listdir(void);
void SaveLog(void);
void MainApp(void);
void TestApp(void);
void UnmountDrive(void);
void ShowSystemVoltage(void);
void ShowCoreTemp(void);
void ShowSHT11Temp(void);
void ShowSHT11Hum(void);
void stopPWM(void);
void startPWM(void);
uint16_t Control_PI(ControlInitTypeDef *ctrl, int16_t objectTemp, int16_t atemp);
void  SetControlValuesKp(ControlInitTypeDef *ctrl, uint16_t kp);
void  SetControlValuesKi(ControlInitTypeDef *ctrl, uint16_t ki);
void  SetControlValuesKd(ControlInitTypeDef *ctrl, uint16_t kd);
void  SetControlValuesDelta(ControlInitTypeDef *ctrl, uint8_t Delta);
uint16_t PWM(TIM_TypeDef* TIMx, int Channel, uint16_t *DutyCycle);
void ShowControlSettings(void);


#endif /* ARMNODE_H_ */


