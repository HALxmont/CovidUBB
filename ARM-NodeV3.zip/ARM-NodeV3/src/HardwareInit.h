/*
 * HardwareInit.h
 *
 *  Created on: 04-01-2019
 *      Author: Usuario
 */

#ifndef HARDWAREINIT_H_
#define HARDWAREINIT_H_

#include "stm32f10x.h"

#define JULIAN_DATE_BASE	2440588

typedef struct {

	uint16_t year;
	uint8_t  month;
	uint8_t  day;
	uint8_t  hour;
	uint8_t  minute;
	uint8_t  second;

} RTC_Init_Time;

/* User defined function prototypes */
void Init_GPIO(void);
void USART1_Init(void);
void led_toggle(void);
void HardwareInit(void);
void USART_puts(USART_TypeDef* USARTx, volatile char *s);
void Init_TMR3(uint16_t period);
void init_CAN(void);
void init_SPI1(void);
void Init_I2C(void);
void Init_TMR4(uint16_t period);
void PeriphClockInit(void);
void Init_SystTick(void);
void Init_IWDG(void);
void Init_WWDG(void);
void InitPWM(void);
void InitPWM1(void);
void Init_RTC(RTC_Init_Time *rtc);
void RTC_GetDateTime(uint32_t RTC_Counter, RTC_Init_Time *rtc);
uint32_t RTC_GetRTC_Counter(RTC_Init_Time *rtc) ;
void InitADCTemp(void);
void InitADC(void);
void Init_EXTI(void);
void Init_EXTI15_10(void);

#endif /* HARDWAREINIT_H_ */
