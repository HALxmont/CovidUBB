/******************************************************************************
 * stm32
 *****************************************************************************/

#include "stm32f10x.h"
#include "HardwareInit.h"
#include "ff.h"
#include "SPISD_DRV.h"
#include <stdio.h>
#include "delays.h"
#include "UserInterface.h"
#include "CanNode.h"
#include "ArmNode.h"
#include "stm32_dsp.h"


int main(void)
{
   FRESULT fresult;
   static FATFS g_sFatFs;

   DBGMCU_Config(DBGMCU_SLEEP, ENABLE);
   HardwareInit();


   delay_nms(20*NODE_ID);

   RTC_Init_Time rtc = {2018,02,28, 10,30,00};
   Init_RTC(&rtc);

   /* Check if the system has resumed from IWDG reset */
   if (RCC_GetFlagStatus(RCC_FLAG_IWDGRST) != RESET)
   {
     /* IWDGRST flag set */
     /* Count the number of IWDG resets and save it to BKP register */
     /* Clear reset flags */
     RCC_ClearFlag();
   }

   ClearScreen();
   info();
   MainMenu();

   fresult = f_mount(&g_sFatFs, "0:", 0);
   delay_nms(10);

   if (fresult == FR_OK)
	   USART_puts(USART1, "SD Card mounted with success \n");
   else
	   USART_puts(USART1, "SD Card mounting error \n");
   stopPWM();


   while(1){

	MainApp();


	   /* Get into sleep mode*/
	   /* Disable systick, useful when you go to sleep mode */
	   SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk;
	   __WFI();
//	   /* Enable systick interrupts, useful when you wakeup from sleep mode */
	   SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;

    }
}




