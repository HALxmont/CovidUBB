
/******************************************************************************
 *  Logger.h
 *  Created on: 10-01-2019
 *  Author: K Herman
 *****************************************************************************/

#ifndef LOGGER_H_
#define LOGGER_H_

#include "stm32f10x.h"
#include "HardwareInit.h"

#define MLX1  0x5a
#define MLX2  0x5b
#define MLX3  0x5c
#define MLX4  0x5d
#define MLX5  0x5e
#define MLX6  0x5f
#define CNT   1


typedef struct {

	uint16_t  		MeasCnt;
	int16_t   		MLX[6];
	uint16_t  		Vcc;
	uint16_t  		CoreTemp;
	uint16_t        AmbientTemp;
	uint16_t		ReadSHTHum;
	int16_t		    ReadSHTTemp;

} Measurement;






void  ResetBKPCounter(void);
uint16_t  GetBKPCounter(void);
void    incBKPCounter(void);
void  ResetBKPLogCounter(void);
uint16_t  GetBKPLogCounter(void);
void    incBKPLogCounter(void);
int16_t ReadMLX(uint8_t address);
int16_t ReadMLXAmbient(uint8_t address);
uint8_t SavetoFile(char *filename);
void MakeMeasurement(void);
uint32_t GetCoreTemp(void);
uint32_t GetSystemVoltage(void);
int16_t ReadSHT1xTemp(void);
uint16_t ReadSHT1xHum(void);
void DisableIRQ(void);
void EnableIRQ(void);
void WriteMLX_EP(uint8_t address, uint8_t reg, uint16_t data, uint8_t pec);
uint16_t ReadMLX_EP(uint8_t address, uint8_t reg) ;



#endif /* LOGGER_H_ */

/****************************************************************************/
