
/******************************************************************************
 * Interrupts.c
 * Created on: 10-01-2019
 * Author: K. Herman
 *****************************************************************************/

#include "HardwareInit.h"
#include "stm32f10x.h"
#include "SPISD_DRV.h"
#include "Logger.h"
#include "delays.h"
#include <stdio.h>
#include "UserInterface.h"
#include "CanNode.h"
#include "ArmNode.h"


extern uint8_t Interval;
extern ITStatus CAN1_IRQ, UART1_IRQ, ALARM_IRQ, TMR4_IRQ, TMR2_IRQ, EXTI_PowerLine, EXTI_ReedSwitch;
extern char ButtonPressed;
extern CanRxMsg msgrx;
extern AppStatus  PWM1State, PWM2State, PWM3State, PWM4State, PWM5State, PWM6State, PIDState;
extern ErrorTypeDef App_Error;
extern uint8_t DEBUG;
extern uint16_t dc[6];

/******************************************************************************
USART1 IRQ handler which controls the user menu
 *****************************************************************************/
void USART1_IRQHandler(void)
{
    /* RXNE handler */
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
    	ButtonPressed = USART_ReceiveData(USART1);
    	if (ButtonPressed == 'r')
    		 NVIC_SystemReset();
     	UART1_IRQ = SET;
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}

/*Timer 1 interrupt for duty cycle*/
void TIM1_CC_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM1, TIM_IT_CC1) != RESET)
    {
    	PWM5State = SET;
    	TIM_ClearITPendingBit(TIM1, TIM_IT_CC1);
    }

    if(TIM_GetITStatus(TIM1, TIM_IT_CC4) != RESET)
    {
    	PWM6State = SET;
    	TIM_ClearITPendingBit(TIM1, TIM_IT_CC4);
    }

}
/* Timer2 interrupt for duty cycle */
void TIM2_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM2, TIM_IT_CC2) != RESET)
    {
    	PWM1State = SET;
    	TIM_ClearITPendingBit(TIM2, TIM_IT_CC2);
    }

}

/*Timer 3 interrupts for duty cycle*/
void TIM3_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM3, TIM_IT_CC1) != RESET)
    {
    	PWM4State = SET;

    	TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);
    }

	if(TIM_GetITStatus(TIM3, TIM_IT_CC3) != RESET)
    {
    	PWM2State = SET;

    	TIM_ClearITPendingBit(TIM3, TIM_IT_CC3);
    }

    if(TIM_GetITStatus(TIM3, TIM_IT_CC4) != RESET)
    {
    	PWM3State = SET;

    	TIM_ClearITPendingBit(TIM3, TIM_IT_CC4);
    }

}
/* Timer 4 IRQ each second*/
void TIM4_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET)
    {
    	PIDState = ENABLE;
    	TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    }

}

/* Can Transmit interrupt */
void USB_HP_CAN1_TX_IRQHandler(void){

	   if (CAN_GetITStatus(CAN1, CAN_IT_TME) != RESET)
	    {
		  if(DEBUG)
			  USART_puts(USART1, "CAN TX IRQ \n");
		  CAN_ClearITPendingBit(CAN1, CAN_IT_TME);
	    }

}



/*Can receive interrupt*/
void USB_LP_CAN1_RX0_IRQHandler(void){


	   if (CAN_GetITStatus(CAN1, CAN_IT_FMP0) != RESET)
	    {
		   CAN_Receive(CAN1, 0, &msgrx);
		   CAN_FIFORelease(CAN1,0);

	    	if ( (msgrx.Data[1] == 0xFF ) && (msgrx.Data[0] == NODE_ID))
	    			NVIC_SystemReset();
		   CAN1_IRQ = SET;
		 /* Pending bit cleared by hardware after reading FIFO*/
		 // CAN_ClearITPendingBit(CAN1, CAN_IT_FMP0);
	    }
}

/* Can error interrupt*/
void CAN1_SCE_IRQHandler(void){

char buffer[30];
App_Error.lec = CAN_GetLastErrorCode(CAN1);
App_Error.tec = CAN_GetLSBTransmitErrorCounter(CAN1);
App_Error.rec = CAN_GetReceiveErrorCounter(CAN1);

	   if (CAN_GetITStatus(CAN1, CAN_IT_EWG) != RESET)
	    {
		   App_Error.CAN = CAN_EWG;
		  if(DEBUG)
			  USART_puts(USART1, "CAN EWG \n");
		  CAN_ClearITPendingBit(CAN1, CAN_IT_EWG);
	    }

	   if (CAN_GetITStatus(CAN1, CAN_IT_EPV) != RESET)
	    {
		  App_Error.CAN = CAN_EPV;
		  if(DEBUG)
			  USART_puts(USART1, "CAN EPV \n");
		  CAN_ClearITPendingBit(CAN1, CAN_IT_EPV);
	    }

	   if (CAN_GetITStatus(CAN1, CAN_IT_BOF) != RESET)
	    {

		  App_Error.CAN = CAN_BOF;
		  if(DEBUG)
			  USART_puts(USART1, "CAN BOF \n");
		  CAN_ClearITPendingBit(CAN1, CAN_IT_BOF);
	    }

	   if (CAN_GetITStatus(CAN1, CAN_IT_LEC) != RESET)
	    {
		  App_Error.CAN = CAN_LEC;

		  if(DEBUG){
			sprintf(buffer,"SC CAN LEC_No 0x%x\n", CAN_GetLastErrorCode(CAN1));
			/* 0x40 - recessive bit error retransmitt */
			USART_puts(USART1, buffer);
		  }


		  CAN_ClearITPendingBit(CAN1, CAN_IT_LEC);
	    }

	   if (CAN_GetITStatus(CAN1, CAN_IT_ERR) != RESET)
	    {
		  App_Error.CAN = CAN_ERR;
		  if(DEBUG)
			  sprintf(buffer,"SC CAN ERR_No 0x%x\n", CAN_GetLastErrorCode(CAN1));
			  							      /* 0x40 - recessive bit error retransmitt */
			   USART_puts(USART1, buffer);
		  CAN_ClearITPendingBit(CAN1, CAN_IT_ERR);
	    }

}

/* RTC Alarm  */
void RTCAlarm_IRQHandler(void){

	   if(DEBUG)
		   USART_puts(USART1,"Hello from RTCAlarm IRQ\n");

	   RTC_ClearFlag(RTC_IT_ALR);
	   RTC_WaitForLastTask();
	   RTC_SetAlarm(RTC_GetCounter()+ 59*Interval);
	   RTC_WaitForLastTask();
}

/* RTC interrupt */
void RTC_IRQHandler(void){



	if(RTC_GetITStatus(RTC_IT_SEC) != RESET){

		PWR_BackupAccessCmd(ENABLE);
		RTC_WaitForLastTask();
		RTC_ClearITPendingBit(RTC_IT_SEC);
		RTC_WaitForSynchro();
		PWR_BackupAccessCmd(DISABLE);

	}

	if(RTC_GetITStatus(RTC_IT_ALR) != RESET){

		ALARM_IRQ = SET;
		PWR_BackupAccessCmd(ENABLE);
		RTC_WaitForLastTask();
		RTC_ClearITPendingBit(RTC_IT_ALR);
		RTC_WaitForSynchro();
		RTC_SetAlarm(RTC_GetCounter()+  59*Interval);
		RTC_WaitForLastTask();
		PWR_BackupAccessCmd(DISABLE);

	}

}


void RCC_IRQHandler(void){

	   if (RCC_GetITStatus(RCC_IT_CSS) != RESET)
	    {
		  if(DEBUG)
			  USART_puts(USART1, "HSE failure \n");
		  RCC_ClearITPendingBit(RCC_IT_CSS);
	    }



}


/* Power Line interrupt */
void EXTI15_10_IRQHandler(void) {

 if (EXTI_GetITStatus(EXTI_Line12) != RESET) {
	 	   EXTI_PowerLine = DISABLE;
	 	   TIM_Cmd(TIM2,DISABLE);
	 	   TIM_Cmd(TIM3,DISABLE);
	 	   TIM_Cmd(TIM1,DISABLE);
	 	   TIM_SetCounter(TIM2, 0x0000);
	 	   TIM_SetCounter(TIM3, 0x0000);
	 	   TIM_SetCounter(TIM1, 0x0000);
		   PWM(TIM2,2, &dc[3]);  			/* PWM3 */
		   PWM(TIM3,3, &dc[4]);  			/* PWM5 */
		   PWM(TIM3,4, &dc[5]);  			/* PWM4 */
		   PWM(TIM3,1, &dc[0]);  			/* PWM0 */
		   PWM(TIM1,1, &dc[2]);  			/* PWM2 */
		   PWM(TIM1,4, &dc[1]);  			/* PWM1 */
	 	   TIM_Cmd(TIM2,ENABLE);
		   TIM_Cmd(TIM3,ENABLE);
		   TIM_Cmd(TIM1,ENABLE);
	 EXTI_ClearITPendingBit(EXTI_Line12);
 }
}
/* Reed Switch Interrupt */
void EXTI9_5_IRQHandler(void) {

 if (EXTI_GetITStatus(EXTI_Line5) != RESET) {
	 EXTI_ReedSwitch  = SET;
    EXTI_ClearITPendingBit(EXTI_Line5);
 }
}


/* Window Watchdog interrupt*/
void WWDG_IRQHandler(void){

	WWDG_ClearFlag();
	if(DEBUG)
		USART_puts(USART1,"Hello from WWDG\n");

}


/*****************************************************************************/
