/******************************************************************************
 * CanNode.c
 *  Created on: 10-01-2019
 *  Author: K. Herman
 *****************************************************************************/

#ifndef CANNODE_H_
#define CANNODE_H_

#define NodeFrame_0_ID  0x10
#define NodeFrame_1_ID  0x11
#define NodeFrame_2_ID  0x12
#define NodeFrame_3_ID  0x13

#define Mask 0x00FF


uint8_t CanTx(CanTxMsg *);
void ParseCanFrame(CanRxMsg *msg);
void CanSendMsg(void);
void ShowCanErr(void);
void EchoCan(uint8_t data);
void SendDataOverCan(void);
void CAN_EnterInitialization(void);
void CAN_EnterNormalMode(void);

#endif /* CANNODE_H_ */
/*****************************************************************************/

