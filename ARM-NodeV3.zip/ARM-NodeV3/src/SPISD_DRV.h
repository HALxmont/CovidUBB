/*
 * SPISD_DRV.h
 *
 *  Created on: 09-01-2019
 *      Author: K. Herman
 */

#ifndef SPISD_DRV_H_
#define SPISD_DRV_H_

#include "ff.h"
#include "diskio.h"


/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */


/*-----------------------------------------------------------------------*/
/* Device Timer Interrupt Procedure  (Platform dependent)                */
/*-----------------------------------------------------------------------*/
/* This function must be called in period of 1ms                        */

void sdcard_systick_timerproc(void);
DSTATUS USER_initialize ( BYTE pdrv );
DRESULT USER_read (BYTE pdrv, BYTE *buff, DWORD sector, UINT count);
DRESULT USER_write ( BYTE pdrv, const BYTE *buff, DWORD sector, UINT count);
void xmit_spi(BYTE Data);

#endif /* SPISD_DRV_H_ */
