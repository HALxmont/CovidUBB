/*
 *      UserInterface.c
 *      Created on: 18-03-2017
 *      Author: Krzysztof Herman
 *	    kherman@ubiobio.cl	
 */
#include "UserInterface.h"
#include "HardwareInit.h"
#include "Logger.h"
#include "ArmNode.h"
#include "CanNode.h"



/**
  * @brief  Global variable to hold menu level
  * @note
  */
volatile uint8_t MenuLevel;
extern volatile Measurement meas;
extern uint8_t DEBUG;
extern uint8_t SD_Write;
extern uint8_t POWERMODE;


void info(void){

    USART_puts(USART1, "This is the ARM Node application \n");


}


void MainMenu(void){

	// Show Current data here
	USART_puts(USART1, "\n -------- BEGIN MAIN MENU ------- \n");
	USART_puts(USART1, "a) Get Node ID \n");
	USART_puts(USART1, "b) Get Current Time\n");
	USART_puts(USART1, "e) Get CAN error \n");
	USART_puts(USART1, "f) List SD Card main directory \n");
	USART_puts(USART1, "i) Get all MLX  sensors measurements  \n");
	USART_puts(USART1, "r) Software  reset  \n");
	USART_puts(USART1, "s) Save to file   \n");
	USART_puts(USART1, "t) Show Core temperature  \n");
	USART_puts(USART1, "u) Unmount SD Card  \n");
	USART_puts(USART1, "v) Show System Voltage  \n");
	USART_puts(USART1, "z) Show SHT temperature  \n");
	USART_puts(USART1, "x) Show SHT humidity  \n");
	USART_puts(USART1, "p) Stop PWM  \n");
	USART_puts(USART1, "l) Start PWM \n");
	USART_puts(USART1, "o) Read MLX Eeprom \n");
	USART_puts(USART1, "k) Write MLX Eeprom \n");
	USART_puts(USART1, "j) CAN deinit\n");
	USART_puts(USART1, "y) CAN init \n");
	USART_puts(USART1, "n) Sanity check \n");
	USART_puts(USART1, "m) Toggle SD Write mode\n");
	USART_puts(USART1, "q) Show PID control Settings \n");
	USART_puts(USART1, "-------- END MAIN MENU ------- \n");
	USART_puts(USART1, "                               \n");
}


void ChoiceSelector(char *choice){


    switch(*choice){

    case 'a': ShowID();  meas.MLX[0] = meas.MLX[0] + 500;
	break;

    case 'b': ShowCurrentTime();
	break;


    case 'e': ShowCanErr();
	break;

    case 'f': listdir();
	break;

    case 'i': readallmlx();
	break;

    case 'r': NVIC_SystemReset();
    break;

    case 's': SaveLog();
	break;

    case 't': ShowCoreTemp();
    break;

    case 'u': UnmountDrive();
	break;

    case 'v': ShowSystemVoltage();
	break;

    case 'z': ShowSHT11Temp();
    break;

    case 'x': ShowSHT11Hum();
    break;

    case 'p': stopPWM(); POWERMODE = 0x00;
    break;

    case 'l': startPWM(); POWERMODE = 0x01;
    break;


    case 'o':  ShowMLXDir();
    break;
    case 'k':  WriteMLXReg();
               SanityCheck();
    break;

    case 'j':  CAN_EnterInitialization();
    break;

    case 'y':  CAN_EnterNormalMode();
    break;

    case 'n':  SanityCheck();
    break;

    case 'm':  SD_Write ^= 0x01;
    		   if(SD_Write)
    			   USART_puts(USART1, "SD Write Set\n");
    		   else
    			   USART_puts(USART1, "SD Write Reset\n");

    break;


    case 'q':  ShowControlSettings();
    break;
    }
}



void inline ClearScreen(void){

	USART_SendData(USART1, 0xC);
}


void SetDebugMode(void){

	DEBUG = SET;
}

void ResetDebugMode(void){

	DEBUG = RESET;
}






