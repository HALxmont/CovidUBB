/******************************************************************************
 * CanNode.c
 *  Created on: 10-01-2019
 *  Author: K Herman
 *****************************************************************************/
#include "stm32f10x.h"
#include "HardwareInit.h"
#include "stm32f10x.h"
#include "SPISD_DRV.h"
#include "Logger.h"
#include "delays.h"
#include <stdio.h>
#include "ArmNode.h"
#include <stdlib.h>
#include "CanNode.h"
#include "UserInterface.h"
/*****************************************************************************/

extern uint8_t SD_Write;
extern 	uint8_t DC_show;
extern uint8_t Interval;
extern uint8_t POWERMODE;
extern AppStatus MainCycle;
extern volatile Measurement meas;
extern uint8_t DEBUG;
extern ControlInitTypeDef ControlModule1;
extern ControlInitTypeDef ControlModule2;
extern ControlInitTypeDef ControlModule3;
extern ControlInitTypeDef ControlModule4;
extern ControlInitTypeDef ControlModule5;
extern ControlInitTypeDef ControlModule6;
extern ErrorTypeDef App_Error;
/**
 * @brief  This function transmits CAN message.
 * @param  CAN message
 * @retval Error code
 */
uint8_t CanTx(CanTxMsg *msg) {

	uint8_t mailbox;
	uint8_t status;
	uint16_t timeout = 0xFFFF;


	/*Transmit message*/
	mailbox = CAN_Transmit(CAN1, msg);

	/* Wait for Mailbox empty */
	while (timeout--) {
		status = CAN_TransmitStatus(CAN1, mailbox);
		if (status == CAN_TxStatus_Ok)
			break;
	}
	if (timeout == 0) {
		if (DEBUG)
			USART_puts(USART1, "Can TX timeout\n");
	}
	return status;
}

void ParseCanFrame(CanRxMsg *msgrx) {

	RTC_Init_Time *rtc;
	CanTxMsg msgtx;
	uint32_t counter;
	uint16_t tempval;
	uint16_t tmp;

	if (msgrx->Data[0] == NODE_ID) {

		switch (msgrx->Data[1]) {

		case 0x00:
			USART_puts(USART1, "Ping the module WKP\n");
			break;
		case 0x01:
			USART_puts(USART1, "Set the current date \n");
			rtc = malloc(sizeof(RTC_Init_Time));
			if (rtc != NULL) {
				rtc->year = 20 * 100 + msgrx->Data[2];
				rtc->month = msgrx->Data[3];
				rtc->day = msgrx->Data[4];
				rtc->hour = msgrx->Data[5];
				rtc->minute = msgrx->Data[6];
				rtc->second = msgrx->Data[7];
				Init_RTC(rtc);
			}
			free(rtc);
			break;
		case 0x02:
			delay_nms(20*NODE_ID);
			tmp = msgrx->Data[2] << 8;
			tmp = tmp + msgrx->Data[2];
			meas.AmbientTemp = tmp;
			MakeMeasurement();
			delay_nms(20*NODE_ID);
			SaveLog();
			if (DEBUG)
				USART_puts(USART1, "About to take the measurement  \n");
			MainCycle = DONE;
			break;

		case 0x03:
			SendDataOverCan();
			SanityCheck();
			if (DEBUG)
				USART_puts(USART1, "About to send data over CAN \n");
			break;

		case 0x04:
			msgtx.DLC = 4;
			msgtx.Data[0] = 0x30;
			msgtx.Data[1] = App_Error.I2C;
			msgtx.Data[2] = App_Error.CAN;
			msgtx.Data[3] = App_Error.FAT;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send App Error Code over CAN \n");

			break;

		case 0x05:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x31;
			msgtx.Data[1] = (uint8_t) (meas.MeasCnt >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MeasCnt;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1,
						"About to send measurement counter over CAN \n");

			break;

		case 0x06:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x32;
			msgtx.Data[1] = (uint8_t) (meas.Vcc >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.Vcc;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);

			if (DEBUG)
				USART_puts(USART1, "About to send system voltage over CAN \n");

			break;

		case 0x07:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x33;
			msgtx.Data[1] = (uint8_t) (meas.CoreTemp >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.CoreTemp;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);

			if (DEBUG)
				USART_puts(USART1, "About to send core temp over CAN \n");

			break;

		case 0x08:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x34;
			msgtx.Data[1] = (uint8_t) (meas.ReadSHTTemp >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.ReadSHTTemp;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);

			if (DEBUG)
				USART_puts(USART1, "About to send air temp over CAN \n");

			break;

		case 0x09:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x35;
			msgtx.Data[1] = (uint8_t) (meas.ReadSHTHum >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.ReadSHTHum;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send air hum over CAN \n");

			break;

		case 0x0A:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x36;
			msgtx.Data[1] = (uint8_t) (meas.MLX[0] >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MLX[0];
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send MLX0 over CAN \n");

			break;

		case 0x0B:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x37;
			msgtx.Data[1] = (uint8_t) (meas.MLX[1] >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MLX[1];
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send MLX1 over CAN \n");

			break;

		case 0x0C:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x38;
			msgtx.Data[1] = (uint8_t) (meas.MLX[2] >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MLX[2];
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send MLX2 over CAN \n");

			break;

		case 0x0D:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x39;
			msgtx.Data[1] = (uint8_t) (meas.MLX[3] >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MLX[3];
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send MLX3 over CAN \n");

			break;

		case 0x0E:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x3A;
			msgtx.Data[1] = (uint8_t) (meas.MLX[4] >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MLX[4];
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send MLX4 over CAN \n");

			break;

		case 0x0F:
			msgtx.DLC = 3;
			msgtx.Data[0] = 0x3B;
			msgtx.Data[1] = (uint8_t) (meas.MLX[5] >> 8);
			msgtx.Data[2] = (uint8_t) 0x00FF & meas.MLX[5];
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send MLX5 over CAN \n");

			break;

		case 0x10:
			msgtx.DLC = 1;
			msgtx.Data[0] = 0x3C;
			msgtx.Data[1] = CAN_GetLSBTransmitErrorCounter(CAN1);
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send TEC over CAN \n");

			break;

		case 0x11:
			msgtx.DLC = 2;
			msgtx.Data[0] = 0x3D;
			msgtx.Data[1] = CAN_GetReceiveErrorCounter(CAN1);
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1, "About to send REC over CAN \n");

			break;

		case 0x12:
			SetDebugMode();
			if (DEBUG)
				USART_puts(USART1, "Debug mode Set CAN \n");

			break;

		case 0x13:
			ResetDebugMode();
			USART_puts(USART1, "Debug mode reset \n");

			break;

		case 0x14:
			counter = RTC_GetCounter();
			rtc = malloc(sizeof(RTC_Init_Time));
			RTC_GetDateTime(counter, rtc);
			if (rtc != NULL) {
				msgtx.Data[0] = 0x3E;
				msgtx.Data[1] = (uint8_t) 20;
				msgtx.Data[2] = (uint8_t) ((rtc->year - 2000) & 0x00FF);
				msgtx.Data[3] = rtc->month;
				msgtx.Data[4] = rtc->day;
				msgtx.Data[5] = rtc->hour;
				msgtx.Data[6] = rtc->minute;
				msgtx.Data[7] = rtc->second;
			}
			free(rtc);

			msgtx.DLC = 8;
			msgtx.ExtId = 0x0;
			msgtx.IDE = CAN_ID_STD;
			msgtx.RTR = CAN_RTR_DATA;
			msgtx.StdId = NODE_ID;
			CanTx(&msgtx);
			if (DEBUG)
				USART_puts(USART1,
						"About to send RTC over CAN 0x14 YY YY MON DAY HH MIN SEC \n");

			break;

		case 0x15:
			switch (msgrx->Data[2]) {

			case 0x01:
				SetControlValuesDelta(&ControlModule1, msgrx->Data[3]);
				if (DEBUG)
					USART_puts(USART1, "Setting DeltaT for PID1 \n");
				break;
			case 0x02:
				SetControlValuesDelta(&ControlModule2, msgrx->Data[3]);
				if (DEBUG)
					USART_puts(USART1, "Setting DeltaT for PID2 \n");
				break;
			case 0x03:
				SetControlValuesDelta(&ControlModule3, msgrx->Data[3]);
				if (DEBUG)
					USART_puts(USART1, "Setting DeltaT for PID3 \n");
				break;
			case 0x04:
				SetControlValuesDelta(&ControlModule4, msgrx->Data[3]);
				if (DEBUG)
					USART_puts(USART1, "Setting DeltaT for PID4 \n");
				break;
			case 0x05:
				SetControlValuesDelta(&ControlModule5, msgrx->Data[3]);
				if (DEBUG)
					USART_puts(USART1, "Setting DeltaT for PID5 \n");
				break;
			case 0x06:
				SetControlValuesDelta(&ControlModule6, msgrx->Data[3]);
				if (DEBUG)
					USART_puts(USART1, "Setting DeltaT for PID6 \n");
				break;

			default:
				if (DEBUG)
					USART_puts(USART1, "Invalid value to set \n");
				break;

			}
			break;

		case 0x16:
			tempval = (uint16_t) (msgrx->Data[3] << 8);
			tempval = (uint16_t) (tempval + msgrx->Data[4]);
			switch (msgrx->Data[2]) {

			case 0x01:
				SetControlValuesKp(&ControlModule1, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kp for PID1 \n");
				break;
			case 0x02:
				SetControlValuesKp(&ControlModule2, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kp for PID2 \n");
				break;
			case 0x03:
				SetControlValuesKp(&ControlModule3, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kp for PID3 \n");
				break;
			case 0x04:
				SetControlValuesKp(&ControlModule4, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kp for PID4 \n");
				break;
			case 0x05:
				SetControlValuesKp(&ControlModule5, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kp for PID5 \n");
				break;
			case 0x06:
				SetControlValuesKp(&ControlModule6, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kp for PID6 \n");
				break;

			default:
				if (DEBUG)
					USART_puts(USART1, "Invalid value to set \n");
				break;

			}
			break;

		case 0x17:
			tempval = (uint16_t) (msgrx->Data[3] << 8);
			tempval = (uint16_t) (tempval + msgrx->Data[4]);
			switch (msgrx->Data[2]) {

			case 0x01:
				SetControlValuesKi(&ControlModule1, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Ki for PID1 \n");
				break;
			case 0x02:
				SetControlValuesKi(&ControlModule2, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Ki for PID2 \n");
				break;
			case 0x03:
				SetControlValuesKi(&ControlModule3, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Ki for PID3 \n");
				break;
			case 0x04:
				SetControlValuesKi(&ControlModule4, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Ki for PID4 \n");
				break;
			case 0x05:
				SetControlValuesKi(&ControlModule5, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Ki for PID5 \n");
				break;
			case 0x06:
				SetControlValuesKi(&ControlModule6, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Ki for PID6 \n");
				break;

			default:
				if (DEBUG)
					USART_puts(USART1, "Invalid value to set \n");
				break;

			}
			break;

		case 0x18:
			tempval = (uint16_t) (msgrx->Data[3] << 8);
			tempval = (uint16_t) (tempval + msgrx->Data[4]);
			switch (msgrx->Data[2]) {

			case 0x01:
				SetControlValuesKd(&ControlModule1, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kd for PID1 \n");
				break;
			case 0x02:
				SetControlValuesKd(&ControlModule2, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kd for PID2 \n");
				break;
			case 0x03:
				SetControlValuesKd(&ControlModule3, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kd for PID3 \n");
				break;
			case 0x04:
				SetControlValuesKd(&ControlModule4, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kd for PID4 \n");
				break;
			case 0x05:
				SetControlValuesKd(&ControlModule5, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kd for PID5 \n");
				break;
			case 0x06:
				SetControlValuesKd(&ControlModule6, tempval);
				if (DEBUG)
					USART_puts(USART1, "Setting Kd for PID6 \n");
				break;

			default:
				if (DEBUG)
					USART_puts(USART1, "Invalid value to set \n");
				break;

			}
			break;

			case 0x19:
				switch (msgrx->Data[2]) {

				case 0x01:
					msgtx.Data[0] = 0x40;
					msgtx.Data[1] = ControlModule1.DeltaT;
					msgtx.Data[2] = (uint8_t) (ControlModule1.kp >> 8);
					msgtx.Data[3] = (uint8_t) (ControlModule1.kp & 0x00FF);
					msgtx.Data[4] = (uint8_t) (ControlModule1.ki >> 8);
					msgtx.Data[5] = (uint8_t) (ControlModule1.ki & 0x00FF);
					msgtx.Data[6] = (uint8_t) (ControlModule1.kd >> 8);
					msgtx.Data[7] = (uint8_t) (ControlModule1.kd & 0x00FF);
					if (DEBUG)
						USART_puts(USART1, "Getting control values of PID1 \n");
					break;
				case 0x02:
					msgtx.Data[0] = 0x41;
					msgtx.Data[1] = ControlModule2.DeltaT;
					msgtx.Data[2] = (uint8_t) (ControlModule2.kp >> 8);
					msgtx.Data[3] = (uint8_t) (ControlModule2.kp & 0x00FF);
					msgtx.Data[4] = (uint8_t) (ControlModule2.ki >> 8);
					msgtx.Data[5] = (uint8_t) (ControlModule2.ki & 0x00FF);
					msgtx.Data[6] = (uint8_t) (ControlModule2.kd >> 8);
					msgtx.Data[7] = (uint8_t) (ControlModule2.kd & 0x00FF);
					if (DEBUG)
						USART_puts(USART1, "Getting control values PID1 \n");
					break;
				case 0x03:
					msgtx.Data[0] = 0x42;
					msgtx.Data[1] = ControlModule3.DeltaT;
					msgtx.Data[2] = (uint8_t) (ControlModule3.kp >> 8);
					msgtx.Data[3] = (uint8_t) (ControlModule3.kp & 0x00FF);
					msgtx.Data[4] = (uint8_t) (ControlModule3.ki >> 8);
					msgtx.Data[5] = (uint8_t) (ControlModule3.ki & 0x00FF);
					msgtx.Data[6] = (uint8_t) (ControlModule3.kd >> 8);
					msgtx.Data[7] = (uint8_t) (ControlModule3.kd & 0x00FF);

					if (DEBUG)
						USART_puts(USART1, "Getting control values PID3 \n");
					break;
				case 0x04:
					msgtx.Data[0] = 0x43;
					msgtx.Data[1] = ControlModule4.DeltaT;
					msgtx.Data[2] = (uint8_t) (ControlModule4.kp >> 8);
					msgtx.Data[3] = (uint8_t) (ControlModule4.kp & 0x00FF);
					msgtx.Data[4] = (uint8_t) (ControlModule4.ki >> 8);
					msgtx.Data[5] = (uint8_t) (ControlModule4.ki & 0x00FF);
					msgtx.Data[6] = (uint8_t) (ControlModule4.kd >> 8);
					msgtx.Data[7] = (uint8_t) (ControlModule4.kd & 0x00FF);
					if (DEBUG)
						USART_puts(USART1, "Getting control values PID4 \n");
					break;
				case 0x05:
					msgtx.Data[0] = 0x44;
					msgtx.Data[1] = ControlModule5.DeltaT;
					msgtx.Data[2] = (uint8_t) (ControlModule5.kp >> 8);
					msgtx.Data[3] = (uint8_t) (ControlModule5.kp & 0x00FF);
					msgtx.Data[4] = (uint8_t) (ControlModule5.ki >> 8);
					msgtx.Data[5] = (uint8_t) (ControlModule5.ki & 0x00FF);
					msgtx.Data[6] = (uint8_t) (ControlModule5.kd >> 8);
					msgtx.Data[7] = (uint8_t) (ControlModule5.kd & 0x00FF);
					if (DEBUG)
						USART_puts(USART1, "Getting control values PID5 \n");
					break;
				case 0x06:
					msgtx.Data[0] = 0x45;
					msgtx.Data[1] = ControlModule6.DeltaT;
					msgtx.Data[2] = (uint8_t) (ControlModule6.kp >> 8);
					msgtx.Data[3] = (uint8_t) (ControlModule6.kp & 0x00FF);
					msgtx.Data[4] = (uint8_t) (ControlModule6.ki >> 8);
					msgtx.Data[5] = (uint8_t) (ControlModule6.ki & 0x00FF);
					msgtx.Data[6] = (uint8_t) (ControlModule6.kd >> 8);
					msgtx.Data[7] = (uint8_t) (ControlModule6.kd & 0x00FF);
					if (DEBUG)
						USART_puts(USART1, "Getting control values PID6 \n");
					break;

				default:
					if (DEBUG)
						USART_puts(USART1, "Invalid value to set \n");
					break;

				}

				if(msgrx->Data[2] >0 && msgrx->Data[2] < 7){
					msgtx.DLC = 8;
					msgtx.ExtId = 0x0;
					msgtx.IDE = CAN_ID_STD;
					msgtx.RTR = CAN_RTR_DATA;
					msgtx.StdId = NODE_ID;
					CanTx(&msgtx);
					if (DEBUG)
						USART_puts(USART1,"About to send Control data over CAN 0x19 Delta KpHI KpLO KiHI KiLO KdHI KdLO \n");
				}
				else{
					if (DEBUG)
						USART_puts(USART1,"Invalid PID controller \n");
				}

			break;

		    case 0x20:
					Interval  = msgrx->Data[2];
					if (DEBUG)
						USART_puts(USART1, "Measurement interval changes \n");

			break;

		    case 0x21:
					POWERMODE  = msgrx->Data[2];
					if (DEBUG)
						USART_puts(USART1, "Power Mode Set/Reset \n");

			break;

		    case 0x22:
					DC_show  = msgrx->Data[2];
					if (DEBUG)
						USART_puts(USART1, "DC send mode Set/Reset \n");

			break;

		    case 0x23:
					SD_Write  = msgrx->Data[2];
					if (DEBUG)
						USART_puts(USART1, "SD Write mode Set/Reset \n");

			break;

		default:
			USART_puts(USART1, "Not such command \n");

			break;
		}

	} else if (msgrx->Data[0] == 0x20) {
		MakeMeasurement();
		if (DEBUG)
			USART_puts(USART1, "Making measurement \n");
	} else if (msgrx->Data[0] == 0xFF) {
		if (DEBUG)
			USART_puts(USART1, "Going to reset \n");
		NVIC_SystemReset();

	} else
		USART_puts(USART1, "Can is not my business \n");

}

void CanSendMsg(void) {

	CanTxMsg msgtx;
	static uint8_t error, lsb, rec;

	msgtx.DLC = 8;
	msgtx.Data[0] = error;
	msgtx.Data[1] = lsb;
	msgtx.Data[2] = rec;
	msgtx.Data[3] = 0;
	msgtx.Data[4] = 0;
	msgtx.Data[5] = 0;
	msgtx.Data[6] = 0;
	msgtx.Data[7] = 0;
	msgtx.ExtId = 0x0;
	msgtx.IDE = CAN_ID_STD;
	msgtx.RTR = CAN_RTR_DATA;
	msgtx.StdId = NODE_ID;
	CanTx(&msgtx);

	error = CAN_GetLastErrorCode(CAN1);
	lsb = CAN_GetLSBTransmitErrorCounter(CAN1);
	rec = CAN_GetReceiveErrorCounter(CAN1);
}

void EchoCan(uint8_t data) {

	CanTxMsg msgtx;

	msgtx.DLC = 1;
	msgtx.Data[0] = data;
	msgtx.ExtId = 0x0;
	msgtx.IDE = CAN_ID_STD;
	msgtx.RTR = CAN_RTR_DATA;
	msgtx.StdId = NODE_ID;
	CanTx(&msgtx);

}

void ShowCanErr(void) {

	uint8_t error, lsb, rec;
	char buffer[32];
	error = CAN_GetLastErrorCode(CAN1);
	lsb = CAN_GetLSBTransmitErrorCounter(CAN1);
	rec = CAN_GetReceiveErrorCounter(CAN1);
	sprintf(buffer, "ErrNo = %d, TEC = %d, REC = %d \n", error, lsb, rec);
	USART_puts(USART1, buffer);
}

void SendDataOverCan(void) {

	/*
	 First frame format
	 | ID |  MeasCnt_Hi  |  MeasCnt_Lo  |   Vcc_Hi    |   Vcc_Lo    | CoreTemp_Hi | CoreTemp_Lo | I2C |
	 Second frame format
	 | ID |   MLX1_Hi    |   MLX1_Lo    |   MLX2_Hi   |   MLX2_Lo   | MLX3_Hi     | MLX3_Lo     | CAN |
	 Third  frame format
	 | ID |   MLX4_Hi    |   MLX4_Lo    |   MLX5_Hi   |   MLX5_Lo   | MLX6_Hi     | MLX6_Lo     | FAT |
	 Fourth  frame format
	 | ID | SHT11Temp_Hi | SHT11Temp_Lo | SHT11Hum_Hi | SHT11Hum_Lo |      last   |      tec    | rec |

	 */

	CanTxMsg msgtx;

	/* general data */
	msgtx.StdId = NODE_ID;
	msgtx.ExtId = 0x0;
	msgtx.IDE = CAN_ID_STD;
	msgtx.RTR = CAN_RTR_DATA;
	msgtx.DLC = 0x08;

	/* make first frame */
	msgtx.Data[0] = NodeFrame_0_ID;
	msgtx.Data[1] = (uint8_t) (meas.MeasCnt >> 8);
	msgtx.Data[2] = (uint8_t) (meas.MeasCnt & Mask);
	msgtx.Data[3] = (uint8_t) (meas.Vcc >> 8);
	msgtx.Data[4] = (uint8_t) (meas.Vcc & Mask);
	msgtx.Data[5] = (uint8_t) (meas.CoreTemp >> 8);
	msgtx.Data[6] = (uint8_t) (meas.CoreTemp & Mask);
	msgtx.Data[7] = (uint8_t) App_Error.I2C;
	/* send frame */
	CanTx(&msgtx);

	/* make second frame */
	msgtx.Data[0] = NodeFrame_1_ID;
	msgtx.Data[1] = (uint8_t) (meas.MLX[0] >> 8);
	msgtx.Data[2] = (uint8_t) (meas.MLX[0] & Mask);
	msgtx.Data[3] = (uint8_t) (meas.MLX[1] >> 8);
	msgtx.Data[4] = (uint8_t) (meas.MLX[1] & Mask);
	msgtx.Data[5] = (uint8_t) (meas.MLX[2] >> 8);
	msgtx.Data[6] = (uint8_t) (meas.MLX[2] & Mask);
	msgtx.Data[7] = (uint8_t) App_Error.CAN;
	/* send frame */
	CanTx(&msgtx);

	/* make third frame */
	msgtx.Data[0] = NodeFrame_2_ID;
	msgtx.Data[1] = (uint8_t) (meas.MLX[3] >> 8);
	msgtx.Data[2] = (uint8_t) (meas.MLX[3] & Mask);
	msgtx.Data[3] = (uint8_t) (meas.MLX[4] >> 8);
	msgtx.Data[4] = (uint8_t) (meas.MLX[4] & Mask);
	msgtx.Data[5] = (uint8_t) (meas.MLX[5] >> 8);
	msgtx.Data[6] = (uint8_t) (meas.MLX[5] & Mask);
	msgtx.Data[7] = (uint8_t) App_Error.FAT;
	/* send frame */
	CanTx(&msgtx);

	/* make fourth frame */
	msgtx.Data[0] = NodeFrame_3_ID;
	msgtx.Data[1] = (uint8_t) (meas.ReadSHTTemp >> 8);
	msgtx.Data[2] = (uint8_t) (meas.ReadSHTTemp & Mask);
	msgtx.Data[3] = (uint8_t) (meas.ReadSHTHum >> 8);
	msgtx.Data[4] = (uint8_t) (meas.ReadSHTHum & Mask);
	msgtx.Data[5] = App_Error.lec;
	msgtx.Data[6] = App_Error.tec;
	msgtx.Data[7] = (uint8_t) App_Error.rec;
	/* send frame */
	CanTx(&msgtx);

}

void CAN_EnterInitialization(void) {

	NVIC_DisableIRQ(CAN1_SCE_IRQn);
	NVIC_DisableIRQ(USB_HP_CAN1_TX_IRQn);
	NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);

	CAN1->MCR |= 0x00000001;
	while (!(CAN1->MSR & 0x1))
		;

	USART_puts(USART1, "CAN init mode \n");

}

void CAN_EnterNormalMode(void) {

	CAN1->MCR &= 0xFFFFFFFE;
	while ((CAN1->MSR & 0x1))
		;
	NVIC_EnableIRQ(CAN1_SCE_IRQn);
	NVIC_EnableIRQ(USB_HP_CAN1_TX_IRQn);
	NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);

	if (DEBUG)
		USART_puts(USART1, "CAN normal mode \n");

}

