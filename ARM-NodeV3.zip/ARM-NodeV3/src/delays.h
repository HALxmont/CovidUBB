
/******************************************************************************
 * delays.h
 *  Created on: 10-01-2019
 *      Author: k Herman
 *****************************************************************************/

#ifndef DELAYS_H_
#define DELAYS_H_

#include "stm32f10x.h"

void TimeTick_Decrement(void);
void delay_nms(uint32_t n);


#endif /* DELAYS_H_ */

/****************************************************************************/
