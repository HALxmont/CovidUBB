/*
 * ArmNode.c
 *
 *  Created on: 26-02-2019
 *      Author: Usuario
 */

#include "ArmNode.h"
#include "stm32f10x.h"
#include "Logger.h"
#include <stdio.h>
#include "delays.h"
#include "string.h"
#include "UserInterface.h"
#include "CanNode.h"

/* triack pulse width */
#define TRIG 200

uint8_t SD_Write = RESET;
uint8_t DC_show = RESET;
uint8_t DEBUG = SET;
uint8_t POWERMODE = RESET;
uint8_t Interval = 1;
ITStatus CAN1_IRQ=RESET, UART1_IRQ=RESET, ALARM_IRQ=RESET, TMR4_IRQ=RESET, EXTI_PowerLine=RESET, EXTI_ReedSwitch=RESET, TMR2_IRQ=RESET;
char ButtonPressed = 0x00;
CanRxMsg msgrx;
AppStatus  MainCycle=WAITING, PWM1State=RESET, PWM2State=RESET, PWM3State=RESET, PWM4State=RESET, PWM5State=RESET, PWM6State=RESET, PIDState=RESET;
extern volatile Measurement meas;
volatile uint16_t dc[6];


ErrorTypeDef App_Error = {Error_App_NoErr,Error_App_NoErr,Error_App_NoErr,0,0,0};

int period=0;
int value=0;

volatile ControlInitTypeDef ControlModule1 = {5,45,2,1,0,0,0,0};
volatile ControlInitTypeDef ControlModule2 = {5,45,2,1,0,0,0,0};
volatile ControlInitTypeDef ControlModule3 = {5,45,2,1,0,0,0,0};
volatile ControlInitTypeDef ControlModule4 = {5,45,2,0,0,0,0,0};
volatile ControlInitTypeDef ControlModule5 = {5,45,2,1,0,0,0,0};
volatile ControlInitTypeDef ControlModule6 = {5,45,2,1,0,0,0,0};


void MainApp(void){

	char buffer[100];
	uint16_t atemp;
   	CanTxMsg msgtx;



	   if(UART1_IRQ == SET){
		    ButtonPressed = USART_ReceiveData(USART1);
	    	ClearScreen();
	    	MainMenu();
	     	ChoiceSelector(&ButtonPressed);
	     	UART1_IRQ = RESET;
	   }

	   if(CAN1_IRQ == SET){
		   ParseCanFrame(&msgrx);
		   CAN1_IRQ = RESET;

	   }

	   if(EXTI_ReedSwitch == SET){
		   if(DEBUG)
			   USART_puts(USART1,"Reed Switch \n");
		   EXTI_ReedSwitch = RESET;
	   }


#ifdef PowerMode

    if(POWERMODE){

	   if(EXTI_PowerLine == SET){
		   EXTI_PowerLine = RESET;
		   TIM_SetCounter(TIM2, 0x0000);
		   TIM_SetCounter(TIM3, 0x0000);
		   TIM_SetCounter(TIM1, 0x0000);
	   }

	   if(PWM1State){

		   PWM1State=RESET;
		   GPIO_SetBits(GPIOA,GPIO_Pin_1);
		   for(int k=1;k<TRIG;k++);
		   GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	   }

	   if(PWM2State){

		   PWM2State=RESET;
		   GPIO_SetBits(GPIOB,GPIO_Pin_0);
		   for(int k=1;k<TRIG;k++);
		   GPIO_ResetBits(GPIOB,GPIO_Pin_0);
	   }

	   if(PWM3State){

		   PWM3State=RESET;
		   GPIO_SetBits(GPIOB,GPIO_Pin_1);
		   for(int k=1;k<TRIG;k++);
		   GPIO_ResetBits(GPIOB,GPIO_Pin_1);
	   }

	   if(PWM4State){

		   PWM4State=RESET;
		   GPIO_SetBits(GPIOB,GPIO_Pin_4);
		   for(int k=1;k<TRIG;k++);
		   GPIO_ResetBits(GPIOB,GPIO_Pin_4);
	   }

	   if(PWM5State){

		   PWM5State=RESET;
		   GPIO_SetBits(GPIOA,GPIO_Pin_8);
		   for(int k=1;k<TRIG;k++);
		   GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	   }

	   if(PWM6State){

		   PWM6State=RESET;
		   GPIO_SetBits(GPIOA,GPIO_Pin_11);
		   for(int k=1;k<TRIG;k++);
		   GPIO_ResetBits(GPIOA,GPIO_Pin_11);
	   }


	   if(PIDState){
		   PIDState = RESET;

		   stopPWM();
		   meas.MLX[0] = ReadMLX(MLX1);
		   meas.MLX[1] = ReadMLX(MLX2);
		   meas.MLX[2] = ReadMLX(MLX3);
		   meas.MLX[3] = ReadMLX(MLX4);
		   meas.MLX[4] = ReadMLX(MLX5);
		   meas.MLX[5] = ReadMLX(MLX6);


		   atemp =  meas.AmbientTemp;

		   dc[0] = Control_PI(&ControlModule1, meas.MLX[0], atemp);
		   dc[1] = Control_PI(&ControlModule2, meas.MLX[1], atemp);
		   dc[2] = Control_PI(&ControlModule3, meas.MLX[2], atemp);
		   dc[3] = Control_PI(&ControlModule4, meas.MLX[3], atemp);
		   dc[4] = Control_PI(&ControlModule5, meas.MLX[4], atemp);
		   dc[5] = Control_PI(&ControlModule6, meas.MLX[5], atemp);


		   startPWM();


		   if(DC_show){

			   	/* general data */
			   	msgtx.StdId = NODE_ID;
			   	msgtx.ExtId = 0x0;
			   	msgtx.IDE = CAN_ID_STD;
			   	msgtx.RTR = CAN_RTR_DATA;
			   	msgtx.DLC = 0x07;

			   	/* make first frame */
			   	msgtx.Data[0] = 0x46;
			   	msgtx.Data[1] = (uint8_t) (dc[0] >> 8);
			   	msgtx.Data[2] = (uint8_t) (dc[0] & Mask);
			   	msgtx.Data[3] = (uint8_t) (dc[1] >> 8);
			   	msgtx.Data[4] = (uint8_t) (dc[1] & Mask);
			   	msgtx.Data[5] = (uint8_t) (dc[2] >> 8);
			   	msgtx.Data[6] = (uint8_t) (dc[2] & Mask);

			   	/* send frame */
			   	CanTx(&msgtx);

			   	/* make second frame */
			   	msgtx.Data[0] = 0x47;
			   	msgtx.Data[1] = (uint8_t) (dc[3] >> 8);
			   	msgtx.Data[2] = (uint8_t) (dc[3] & Mask);
			   	msgtx.Data[3] = (uint8_t) (dc[4] >> 8);
			   	msgtx.Data[4] = (uint8_t) (dc[4] & Mask);
			   	msgtx.Data[5] = (uint8_t) (dc[5] >> 8);
			   	msgtx.Data[6] = (uint8_t) (dc[5] & Mask);

			   	/* send frame */
				CanTx(&msgtx);

		   }

		   if(DEBUG){
			   sprintf(buffer, "To = %d, Ta = %d, error = %d , DC = %d\n", meas.MLX[0], atemp, (ControlModule1.DeltaT*100+atemp)-meas.MLX[0], dc[0]);
	   	   USART_puts(USART1, buffer);
		   	   sprintf(buffer, "To = %d, Ta = %d, error = %d, DC = %d\n", meas.MLX[1], atemp, (ControlModule2.DeltaT*100+atemp)-meas.MLX[1], dc[1]);
		   	   USART_puts(USART1, buffer);
			   sprintf(buffer, "To = %d, Ta = %d, error = %d , DC = %d\n", meas.MLX[2], atemp, (ControlModule3.DeltaT*100+atemp)-meas.MLX[2], dc[2]);
		   	   USART_puts(USART1, buffer);
			   sprintf(buffer, "To = %d, Ta = %d, error = %d, DC = %d\n", meas.MLX[3], atemp, (ControlModule4.DeltaT*100+atemp)-meas.MLX[3], dc[3]);
		   	   USART_puts(USART1, buffer);
			   sprintf(buffer, "To = %d, Ta = %d, error = %d, DC = %d\n", meas.MLX[4], atemp, (ControlModule5.DeltaT*100+atemp)-meas.MLX[4], dc[4]);
		   	   USART_puts(USART1, buffer);
			   sprintf(buffer, "To = %d, Ta = %d, error = %d, DC = %d\n", meas.MLX[5], atemp, (ControlModule6.DeltaT*100+atemp)-meas.MLX[5], dc[5]);
		   	   USART_puts(USART1, buffer);
		   }

		   //SanityCheck();
	   }
    }
#endif

	   if(ALARM_IRQ == SET){
		   ALARM_IRQ = RESET;

		   if(MainCycle == WAITING){
			   if(DEBUG)
				   USART_puts(USART1,"Alarm started measurements\n");
		       MakeMeasurement();
		       meas.AmbientTemp = meas.ReadSHTTemp;
		       SendDataOverCan();
		       SanityCheck();
		   	   SaveLog();
		   }
		   else{
			   if(DEBUG)
				   USART_puts(USART1,"Measurements already started by CAN\n");
			   MainCycle = WAITING;
		   }
	   }

}


void readallmlx(void){

	int16_t tvalue;
	char buffer[50];


for (int i=0; i<6;i++){
	tvalue = ReadMLX(MLX1+i);
	led_toggle();
	sprintf(buffer,"Sensor 0x%x  Temp  value = %d \n",MLX1+i, tvalue);
	USART_puts(USART1, buffer);
	delay_nms(10);
}
}

void ShowID(void){

	char buffer[50];
	sprintf(buffer,"Node ID: %d \n",NODE_ID);
	USART_puts(USART1, buffer);

}

void ShowCurrentTime(void){

	uint32_t tm;
	char buffer[50];
    RTC_Init_Time rtc;

	tm = RTC_GetCounter();
	RTC_GetDateTime(tm, &rtc);
	sprintf(buffer,"%d-%d-%d  %d:%d:%d\n", rtc.year, rtc.month, rtc.day, rtc.hour, rtc.minute, rtc.second) ;
	USART_puts(USART1, buffer);
}


FRESULT scan_files (char* path){

	FRESULT res;
    DIR dir;
    UINT i;
    static FILINFO fno;
    char buff[32];

    res = f_opendir(&dir, path);
    if (res == FR_OK) {
        for (;;) {
            res = f_readdir(&dir, &fno);
            if (res != FR_OK || fno.fname[0] == 0) break;
            if (fno.fattrib & AM_DIR) {
                i = strlen(path);
                sprintf(&path[i], "/%s", fno.fname);
                res = scan_files(path);
                if (res != FR_OK) break;
                path[i] = 0;
            } else {
                sprintf(buff, "%s\n",fno.fname);
                USART_puts(USART1, buff);
            }
        }
        f_closedir(&dir);
    }

    return res;
}

void listdir(void){

	char buff[10];
	strcpy(buff, "/");
	scan_files(buff);

}

void SaveLog(void){

	static char filename[64];
	static uint8_t fnum;

	if (fnum == 0){
			sprintf(filename,"Log-%d.csv", GetBKPLogCounter());
			IncBKPLogCounter();
	}
	USART_puts(USART1, filename);
	SavetoFile(filename);
	fnum = (fnum+1)%13;
}

void ShowCoreTemp(void){

	char buffer[50] = {'\0'};

	sprintf(buffer, "Core temp = %d C\n", (int) GetCoreTemp());
	USART_puts(USART1, buffer);

}

void ShowPeriod(void){

	char buffer[50] = {'\0'};

	sprintf(buffer, "Period = %d [us]\n", period*16/72);
	USART_puts(USART1, buffer);

}


void ShowSystemVoltage(void){

	char buffer[50] = {'\0'};

	sprintf(buffer, "System Voltage = %d [mV] \n", (int) GetSystemVoltage());
	USART_puts(USART1, buffer);

}



void ShowSHT11Temp(void){

	char buffer[50] = {'\0'};

	sprintf(buffer, "SHT11 temperature = %d \n", ReadSHT1xTemp());
	USART_puts(USART1, buffer);

}

void ShowSHT11Hum(void){

	char buffer[50] = {'\0'};

	sprintf(buffer, "SHT11 hum = %d \n", ReadSHT1xHum());
	USART_puts(USART1, buffer);

}


void ShowMLXDir(void){

	char buffer[50] = {'\0'};

	sprintf(buffer, "Dir  = %x \n", ReadMLX_EP(0x5A,0x04));
	USART_puts(USART1, buffer);

}

void WriteMLXReg(void){


	WriteMLX_EP(0x5A,0x04,0x0000,0xb1);
	delay_nms(2);
	WriteMLX_EP(0x5A,0x04,0xFEDC, 0x3f);
	USART_puts(USART1, "Written \n");

}


void UnmountDrive(void){

	f_mount(0, "", 0);
}

void stopPWM(void){

	char buffer[50] = {'\0'};

	if(DEBUG){
		sprintf(buffer, " PWM is down \n");
		USART_puts(USART1, buffer);
	}

	NVIC_DisableIRQ(EXTI15_10_IRQn);
	TIM_Cmd(TIM1, DISABLE);
	TIM_Cmd(TIM2, DISABLE);
	TIM_Cmd(TIM3, DISABLE);
	TIM_Cmd(TIM4, DISABLE);

}

void startPWM(void){

	char buffer[50] = {'\0'};
	uint8_t errcode=0;

	if(DEBUG){
		sprintf(buffer, " PWM is up \n");
		USART_puts(USART1, buffer);
	}

	NVIC_EnableIRQ(EXTI15_10_IRQn);
	TIM_Cmd(TIM1, ENABLE);
	TIM_Cmd(TIM2, ENABLE);
	TIM_Cmd(TIM3, ENABLE);
	TIM_Cmd(TIM4, ENABLE);

}


/**
 * @brief DutyCycle for PWM set function
 * @param1  Timer select
 * @param2 Channel select
 * @param3  Duty cycle set
 * @return Pulse value to be loaded into the Capture Compare Register
 * @note Something to note.
 */
uint16_t PWM(TIM_TypeDef* TIMx, int channel, uint16_t *DutyCycle){

	volatile uint16_t DC;

	DC = *DutyCycle;


	switch(channel){

	case 1: TIMx->CCR1 = DC;
	break;

	case 2: TIMx->CCR2 = DC;
	break;

	case 3: TIMx->CCR3 = DC;
	break;

	case 4: TIMx->CCR4 = DC;
	break;
	}

	//delay_nms(1);
	return DC;
}


uint16_t Control_PI(ControlInitTypeDef *ctrl, int16_t objectTemp, int16_t atemp){


uint16_t output;
/* the MLX and SHT11 sensor provides temperatures  in Celcius * 100 */
/* for testing a fixed set point can be applied here*/
  	ctrl->error = (atemp + ctrl->DeltaT*100) - objectTemp;
//	error = 5;
	ctrl->integral = ctrl->error + ctrl->pastError;
	ctrl->derivativo = ctrl->error - ctrl->pastError;

	ctrl->pastError = ctrl->error;
//
//	if(ctrl->integral > IntegralLimit)
//		ctrl->integral = IntegralLimit;
//	if(ctrl->integral < -IntegralLimit)
//		ctrl->integral = -IntegralLimit;
	output = (ctrl->error*ctrl->kp)/1  + (ctrl->integral*ctrl->ki)/1 + (ctrl->derivativo*ctrl->kd)/1;
    //output = output;
	if(output > MAX_PWM)
		return (MAX_PWM);
	if(output < MIN_PWM)
		return (MIN_PWM);

	//output = 56000-output;
	return output;

}

//
//int16_t Control_PI(ControlInitTypeDef *ctrl, int16_t objectTemp, uint16_t atemp)
//{
//
//	int  output;
//	int IntTerm_C;
//	int  PrevError_C;
//
//  ctrl->error = (atemp + ctrl->DeltaT*100) - objectTemp;
//
//  IntTerm_C += (ctrl->ki*ctrl->error)/10;
//  output = ctrl->kp * ctrl->error;
//  output += IntTerm_C;
//  output += ctrl->kd*(ctrl->error - PrevError_C);
//
//  PrevError_C = ctrl->error;
//
//  	if(output > MAX_PWM)
//  		return MAX_PWM;
//  	if(output < MIN_PWM)
//  		return MIN_PWM;
//
//
//  return (int16_t) output;
//}

void SanityCheck(){

	char buffer[50] = {'\0'};
	uint8_t errcode = 0;

	switch(App_Error.I2C){

		case Error_App_NoErr:
			if(DEBUG){
				sprintf(buffer, "SC no error\n");
				USART_puts(USART1, buffer);
			}
		break;

		case I2C_GetFlagStatusTimeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_GetFlagStatusTimeout\n");
				USART_puts(USART1, buffer);
			}
		break;

		case I2C_EVENT_MASTER_MODE_SELECT_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_EVENT_MASTER_MODE_SELECT_Timeoutr\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_FLAG_TIMEOUTErr:
			if(DEBUG){
				sprintf(buffer, "SC I2C_FLAG_TIMEOUTErr\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_EVENT_MASTER_BYTE_TRANSMITTED_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_MODE_SELECT2_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_EVENT_MASTER_MODE_SELECT2_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_BYTE_RECEIVED_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_EVENT_MASTER_BYTE_RECEIVED_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_BYTE_RECEIVED2_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC  I2C_EVENT_MASTER_BYTE_RECEIVED2_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;
		case I2C_EVENT_MASTER_BYTE_RECEIVED3_Timeout:
			if(DEBUG){
			sprintf(buffer, "SC I2C_EVENT_MASTER_BYTE_RECEIVED3_Timeout\n");
			USART_puts(USART1, buffer);
			}
		break;
		case I2C_FLAG_STOPF_Timeout:
			if(DEBUG){
				sprintf(buffer, "SC I2C_FLAG_STOPF_Timeout\n");
				USART_puts(USART1, buffer);
			}
		break;

		default:
		break;
	}

/* CAn error check*/
	switch(App_Error.CAN){

		case CAN_EWG:
			if(DEBUG){
				sprintf(buffer, "SC CAN EWG\n");
				USART_puts(USART1, buffer);
			}
		break;

		case CAN_EPV:
			if(DEBUG){
				sprintf(buffer, "SC CAN EPV\n");
				USART_puts(USART1, buffer);
			}
		break;

		case CAN_BOF:
			if(DEBUG){
				sprintf(buffer, "SC CAN BOF\n");
				USART_puts(USART1, buffer);
			}
		break;

		case CAN_LEC:
			  errcode = CAN_GetLastErrorCode(CAN1);
			  if(DEBUG){
					sprintf(buffer,"SC CAN LEC_No 0x%x \n", errcode);
								      /* 0x40 - recessive bit error retransmitt */
								     USART_puts(USART1, buffer);
			  }
			  //SendDataOverCan();
		break;

		case CAN_ERR:
			if(DEBUG){
				 sprintf(buffer,"SC CAN ERR_No 0x%x \n", CAN_GetLastErrorCode(CAN1));
			      /* 0x40 - recessive bit error retransmitt */
			     USART_puts(USART1, buffer);
			}
		break;

		default:
		break;
	}

	App_Error.I2C  = Error_App_NoErr;
    App_Error.FAT  = Error_App_NoErr;
	App_Error.CAN  = Error_App_NoErr;
}

void  SetControlValuesDelta(ControlInitTypeDef *ctrl, uint8_t Delta){

		ctrl->DeltaT = Delta;
}

void  SetControlValuesKp(ControlInitTypeDef *ctrl, uint16_t kp){

		ctrl->kp = kp;

}


void  SetControlValuesKi(ControlInitTypeDef *ctrl,  uint16_t ki){

		ctrl->ki = ki;
}

void  SetControlValuesKd(ControlInitTypeDef *ctrl,  uint16_t kd){

	ctrl->kd = kd;
}


void ShowControlSettings(void){

	char buffer[50];
	sprintf(buffer, "Delta = %d, Kp = %d, Ki = %d, Kd = %d\n", ControlModule1.DeltaT, ControlModule1.kp, ControlModule1.ki, ControlModule1.kd );
	USART_puts(USART1, buffer);

	sprintf(buffer, "Delta = %d, Kp = %d, Ki = %d, Kd = %d\n", ControlModule2.DeltaT, ControlModule2.kp, ControlModule2.ki, ControlModule2.kd );
	USART_puts(USART1, buffer);

	sprintf(buffer, "Delta = %d, Kp = %d, Ki = %d, Kd = %d\n", ControlModule3.DeltaT, ControlModule3.kp, ControlModule3.ki, ControlModule3.kd );
	USART_puts(USART1, buffer);

	sprintf(buffer, "Delta = %d, Kp = %d, Ki = %d, Kd = %d\n", ControlModule4.DeltaT, ControlModule4.kp, ControlModule4.ki, ControlModule4.kd );
	USART_puts(USART1, buffer);

	sprintf(buffer, "Delta = %d, Kp = %d, Ki = %d, Kd = %d\n", ControlModule5.DeltaT, ControlModule5.kp, ControlModule5.ki, ControlModule5.kd );
	USART_puts(USART1, buffer);

	sprintf(buffer, "Delta = %d, Kp = %d, Ki = %d, Kd = %d\n", ControlModule6.DeltaT, ControlModule6.kp, ControlModule6.ki, ControlModule6.kd );
	USART_puts(USART1, buffer);

}





